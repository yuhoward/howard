//main.js
var subMain = function () {
    var layoutMain = function (initParams) {
        //* CSS *//
        var css = ` .shawn-star{background-image: url(${subHandler.subFolder}/img/star.png) !important}  background-repeat: no-repeat;height: 16px;`;
        Ext.util.CSS.createStyleSheet(css);
        var mainId = subHandler.mainId || subHandler.parentId;
        //欄位類型Store
        var fieldTypeStore = new Ext.data.JsonStore({ autoDestroy: true, fields: [{ name: "sn", type: "string" }, { name: "title", type: "string" }], data: initParams.fieldTypeDatas });
        //狀態Store 0:停用 1:啟用 2:全部顯示
        var stateStore = new Ext.data.JsonStore({ autoDestroy: true, fields: [{ name: 'sn', type: 'string' }, { name: 'title', type: 'string' }], data: [{ sn: 0, title: "停用" }, { sn: 1, title: "啟用" }, { sn: 2, title: "全部顯示" }] });
        //* 自訂變數 *//
        var editor_temp = null;//部門設定
        var formatWin = null;//欄位設定win
        var JsonEditor = null;
        var sort_temp = null;//開啟視窗時的排序
        var stateValue = 1;//啟用停用
        //* function *//
        var spot = new Ext.ux.Spotlight({ easing: 'easeInOutBounce', duration: .35 });//遮罩
        var otherSetting = function (isSelect, record, gird) {
            if (isSelect) {//true=>有選取主題
                var title = record.get('title') || '尚未設定主題'
                if (gird == 'favoriteGrid') title = '單:' + title;
                JSONPanel.getTopToolbar().get('jsonTitle').setText(`目前選取主題：<span style="color:red;border:solid 2px yellow; padding:2px;">${title}</span>`);
                //我的最愛相關設定(favoriteGrid)
                favoriteGrid.setTitle(`我的最愛( <span style="color:red;border:solid 2px yellow; padding:2px;">${title}</span> )`);
                //將選的主題文字紀錄=>放置產生(臨時)QRcode按鈕中
                JSONPanel.getTopToolbar().get('produceBtn').subject = record.get('title');

            } else {//false
                JSONPanel.getTopToolbar().get('jsonTitle').setText(`目前選取主題：<span style="color:red">未選取</span>`);
                //我的最愛相關設定(favoriteGrid)
                favoriteGrid.setTitle(`我的最愛( <span style="color:red">未選取主題</span> )`);
                QRcodePanel.setTitle('QRcode條碼預覽');
            }
            //(QRcodePanel)
            var stateSn = QRcodeGrid.getTopToolbar().get('stateCombe').getValue();
            JSONPanel.getTopToolbar().get('favoriteBtn').setDisabled(stateSn == '0');
            // JSONPanel.getTopToolbar().get('produceBtn').setDisabled(!isSelect);
            // JSONPanel.getTopToolbar().get('copyBtn').setDisabled(!isSelect);
        }
        var win_refreshData = function (action, field) {
            //格式欄位處理
            var formatResult = formatStore.getRange().map(r => r.get('param') + '：' + r.get('title')).join('<br>');
            formatWin.record.set('format', formatResult);
            //範例欄位處理
            if (field == 'param' || action == 'add' || action == 'delete' || action == 'sort') {
                var exampleResultObj = {};
                exampleResultObj["type"] = formatWin.record.get('type').toString();//先放入type
                formatStore.getRange().forEach(r => exampleResultObj[r.get('param')] = "");//再跑store資料
                formatWin.record.set('example', JSON.stringify(exampleResultObj));
                //編輯器處理
                JsonEditor.set(exampleResultObj);
            }
        }
        var grid_refreshData = function (record) {
            //範例欄位處理
            var exampleResultObj = JSON.parse(record.get('example'));
            //更新type選項
            exampleResultObj["type"] = record.get('type').toString();
            //設定回原欄位
            record.set('example', JSON.stringify(exampleResultObj));
            //編輯器處理
            JsonEditor.set(exampleResultObj);
        }
        var resetData = function (btn) {
            if (btn == 'refreshBtn') {
                QRcodeGrid.getTopToolbar().get('stateCombe').setValue(1);
                stateValue = 1;
                QRcodeStore.baseParams = { keyWord: "", stateSn: 1 };
                QRcodeStore.load();
            } else if (btn == 'specialkey_enter') {
                var state = QRcodeGrid.getTopToolbar().get('stateCombe').getValue();
                QRcodeStore.baseParams = { keyWord: "", stateSn: state };
                QRcodeStore.load();
            }
            favoriteStore.setBaseParam('sn', "");
            favoriteStore.load();
            //清空編輯器
            JsonEditor.set({});
            //右下角圖案
            QRcodePanel.update(
                `<div style="display: flex;justify-content: center; align-items:center; height:100%;">` +
                `${printQRcodeImage()}` +
                `</div>`
            );
            //其他設定
            otherSetting(false, null);
        }
        var selectedModifyRecord = function () {
            //將焦點移回新增/修改的record
            var rI = QRcodeStore.findBy(r => r.get('sn') == formatWin.record.get('sn'));
            QRcodeGrid.getView().focusRow(rI);
            QRcodeGrid.getSelectionModel().selectRow(rI);
        }
        var rowEditAjax = function (sn, e) {//QRcodeGrid
            Ext.Ajax.request({
                method: 'POST', url: subHandler.subController + '&action=editData',
                params: { sn: sn, fieldName: e.field, fieldValue: e.value, oriValue: e.originalValue },
                success: function (result, request) {//連線成功
                    if (sn === 0) {//新增
                        var resultArr = result.responseText.split(',');
                        var resultType = resultArr[0], newSn = resultArr[1];
                        if (resultType == 'okAdd') {
                            e.record.set('sn', newSn);
                            e.record.set('example', `{"type":"${e.value.toString()}"}`);//處理新增的type JsonEditor
                            QRcodeGrid.getSelectionModel().selectFirstRow();//焦點移至第一筆
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:green">新增成功!</span>', 5, 100);
                        } else if (resultType == 'error') {//編號重複
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:red">新增失敗<br>編號已存在!</span>', 5, 120);
                            QRcodeStore.remove(e.record);
                        } else {
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:red">新增失敗:' + result.responseText + '</span>', 5, 120);
                            QRcodeStore.remove(record);
                        }
                    } else {//編輯
                        if (result.responseText === 'okEdit') {
                            if (e.field === 'depSn') { e.record.set('depName', editor_temp); }
                            if (e.field === 'prinUSn') { e.record.set('prinName', editor_temp); }
                            if (e.field === 'type') {
                                grid_refreshData(e.record);
                                favoriteStore.load();
                            }
                            if (e.field === 'title') {
                                var title = e.value || '尚未設定主題'
                                favoriteGrid.setTitle(`我的最愛( <span style="color:red;border:solid 2px yellow; padding:2px;">${title}</span> )`);
                                JSONPanel.getTopToolbar().get('jsonTitle').setText(`目前選取主題：<span style="color:red;border:solid 2px yellow; padding:2px;">${title}</span>`);
                                favoriteStore.setBaseParam('sn', e.record.get('sn'));
                                favoriteStore.load();
                            }
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:green">更新成功!</span>', 2, 100);
                            e.record.commit();
                        } else {
                            var resultArr = result.responseText.split(',');
                            if (resultArr[0] === 'error') {//修改編號重覆
                                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">此編號已存在!</span>', 3, 120);
                            } else {//其他錯誤
                                Ext.Msg.alert('Error', '編輯失敗:' + result.responseText);
                            }
                            e.record.set(e.field, e.originalValue);
                        }
                    }
                },
                failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); record.set(e.field, e.originalValue); },
            });
        }
        var editFormatAjax = function (sn, e) {//formatGrid
            Ext.Ajax.request({
                method: 'POST', url: subHandler.subController + '&action=editFormat',
                params: { sn: sn, fSn: e.record.get('fSn'), fieldName: e.field, fieldValue: e.value },
                success: function (result, request) {
                    if (sn === 0) {//新增
                        var resultArr = result.responseText.split(',');
                        var resultType = resultArr[0], newSn = resultArr[1];
                        if (resultType == 'ok') {
                            e.record.set('sn', newSn);
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:green">新增成功!</span>', 5, 100);
                            win_refreshData('add', null);//刷新資料
                            selectedModifyRecord();
                        } else if (resultType == 'error') {//輸入值重複
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:red">新增失敗<br>欄位已存在!</span>', 5, 120);
                            formatStore.remove(e.record);
                        }
                    } else {//編輯
                        if (result.responseText === 'ok') {
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:green">更新成功!</span>', 2, 100);
                            win_refreshData('edit', e.field);//刷新資料
                        } else {
                            var resultArr = result.responseText.split(',');
                            if (resultArr[0] === 'error') {//修改有重複值
                                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">編輯失敗:已有相同名稱!</span>', 3, 180);
                            } else {//其他錯誤
                                Ext.Msg.alert('Error', '編輯失敗:' + result.responseText);
                            }
                            e.record.set(e.field, e.originalValue);
                        }
                        selectedModifyRecord();
                    }
                },
                failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
            });
        }
        var openFormatWin = function (record) {
            formatWin = formatWin || new Ext.Window({
                iconCls: '', title: '', height: 300, width: 300, border: false, layout: 'fit',
                resizable: true, modal: false, closable: true, constrain: true, constrainHeader: true,
                closeAction: 'hide', maximizable: false, maximized: false,//隱藏視窗,視窗可最大化,直接觸發最大化
                items: [formatGrid],
                //自訂變數
                record: null,
                listeners: {
                    show: function (_this) {
                        formatStore.setBaseParam('sn', _this.record.get('sn'));
                        formatStore.load({ callback: function (rs, o, s) { sort_temp = rs.map(r => r.get('sn')).join(','); } });
                    },
                    beforehide: function (_this) {
                        return !formatGrid.isSortMode;
                    }
                }
            });
            //初始化
            formatWin.setTitle(record.get('title') + '-(欄位管理)');
            formatWin.record = record;
            formatWin.hide();
            formatWin.show();
        }
        var printQRcodeImage = function (text) {
            var image = (!!text) ?
                `<img src="/system_mvc/function/qrcode/php/qr_img.php?s=8&d=${encodeURIComponent(text.replace(/[\r\n]/g, ""))}" height="250" width="250"  style="border:2px solid #aeb8ba">` :
                `<img src=${subHandler.subFolder + '/img/default.png'} height="250" width="250"  style="border:2px solid #aeb8ba">`;
            return `${image}`;
        }
        var checkEdit = function (text) {
            var pass = true;
            //1.判斷是不是json
            if (!isJson(text)) {
                pass = false;
                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">設定失敗,JSON格式有誤請確認!</span>', 5, 230);
                return pass;
            }
            //2.取得下方type屬性
            var jsonObj = JSON.parse(text);
            var type = jsonObj["type"];
            if (!type) {
                pass = false;
                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">設定失敗,未讀取到type欄位!</span>', 5, 230);
                return pass;
            }
            //3.取得相對應的type規則(上表)
            var recordIndex = QRcodeStore.findBy(r => r.get('type') == type);
            if (recordIndex < 0) {
                pass = false;
                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">設定失敗<br>無此type或此type已停用</span>', 5, 200);
                return pass;
            }
            //4.與範例比對每個屬性是否都相同
            var exampleObj = JSON.parse(QRcodeStore.getAt(recordIndex).get('example'));
            var exampleStr = Object.keys(exampleObj).map(key => key).join(',');
            var imputStr = Object.keys(JSON.parse(text)).map(key => key).join(',');
            if (exampleStr !== imputStr) {
                pass = false;
                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">設定失敗<br>與「範例」的格式不相同。</span>', 5, 200);
                return pass;
            }
            return pass;
        }
        var afterEditExample = function (e) {
            var record = e.record;
            Ext.Ajax.request({
                method: 'POST', url: subHandler.subController + '&action=editExample',
                params: { sn: record.get('sn'), fieldName: e.field, fieldValue: e.value },
                success: function (result, request) {
                    if (result.responseText == 'okEdit') {
                        record.set(e.field, e.value);
                        Ext.ux.TopMsg.msg('提醒', '<span style="color:green">更新成功!</span>', 2, 100);
                        record.commit();
                    } else {
                        record.set(e.field, e.originalValue);
                        Ext.Msg.alert('Error', '[編輯失敗]失敗:' + result.responseText);
                    }
                },
                failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
            });
        }
        //*--formatGrid & Store---
        var formatStore = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({ url: `${subHandler.subController}&action=loadFormat&dummy=${new Date().getTime()}`, method: 'POST' }),
            reader: new Ext.data.JsonReader({
                totalProperty: 'total', root: 'data',
                fields: [
                    { name: 'sn', type: 'int' },//sn
                    { name: 'fSn', type: 'int' },//QRcodeStore的sn
                    { name: 'param', type: 'string' },//欄位
                    { name: 'title', type: 'string' },//欄位(中文名稱)
                    { name: 'typeSn', type: 'string' },//欄位類型
                ]
            }),
            listeners: { load: function (_this, records, object) { } }
        });
        var formatGrid = new Ext.grid.EditorGridPanel({
            title: '', iconCls: '', border: true, autoExpandColumn: 3,
            ddGroup: 'formatDDGroup', enableDragDrop: true, rowDDLine: null,
            loadMask: true, stripeRows: true, columnLines: true, trackMouseOver: true, enableColumnMove: false, //讀取圖案,條紋列顏色,分隔線,滑鼠滑過,欄位拖拉
            selModel: new Ext.grid.RowSelectionModel({ singleSelect: true, moveEditorOnEnter: false, }), //列單選
            store: formatStore,
            cm: new Ext.grid.ColumnModel({
                defaults: { align: 'center', sortable: false, menuDisabled: true,/*fixed:true,*/ },
                columns: [
                    { hidden: true, header: 'sn', dataIndex: 'sn', },
                    { hidden: true, header: 'QRcodeGrid_Sn', dataIndex: 'fSn', },
                    {
                        header: '欄位', dataIndex: 'param', width: 80, editor: new Ext.form.TextField({
                            listeners: {
                                //離開焦點或按enter時, 如果sn=0 & 沒輸入, 代表存入失敗, 刪除該列
                                blur: function (_this) {
                                    var record = _this.gridEditor.record;
                                    if (record.get('sn') === 0 && _this.getValue() === '') {
                                        formatStore.remove(record);
                                    }
                                },
                                specialkey(_this, e) {
                                    if (e.getKey() === e.ENTER || e.getKey() === e.TAB) {
                                        var record = _this.gridEditor.record;
                                        var isRepeat = formatStore.getRange().some(r => r.get('param') == _this.getValue());
                                        if (isRepeat) {
                                            formatStore.remove(record);
                                            (function () { formatGrid.stopEditing(); }).defer(1);
                                        }
                                    }
                                }
                            }
                        })
                    },
                    { header: '中文名稱', dataIndex: 'title', editor: new Ext.form.TextField() },
                    {
                        hidden: true, header: '欄位類型', dataIndex: 'typeSn', width: 70,
                        editor: new Ext.form.ComboBox({
                            typeAhead: true, triggerAction: "all", mode: "local",
                            editable: false, listWidth: 70, store: fieldTypeStore, valueField: "sn", displayField: "title", //主要回傳後端值,顯示名稱,
                        }),
                        renderer: function (v, m, r, rI, cI, s) {
                            switch (v) {
                                case "1": return "字串";
                                case "2": return "數字";
                                case "3": return "陣列";
                            }
                        }
                    },
                ],
            }),
            tbar: [
                {
                    xtype: 'button', text: '排序', tooltip: '排序', iconCls: 'exchange', enableToggle: true, handler(btn) {
                        var isSortMode = formatGrid.isSortMode = btn.pressed;
                        if (isSortMode) { //排序
                            formatGrid.view.dragZone.unlock();//解鎖更改功能
                            btn.setText('結束'); //元件調整    
                            btn.setIconClass('ok');
                            btn.el_temp = document.createElement('span');
                            document.body.appendChild(btn.el_temp);
                            spot.show(btn.el_temp);//啟用遮罩
                            formatWin.el.dom.querySelector(".x-tool-close").style.display = "none";//隱藏win【x】
                        } else { //完成排序
                            formatGrid.view.dragZone.lock();//鎖上不讓更改
                            btn.setText('排序');
                            btn.setIconClass('exchange');
                            spot.hide();//關閉遮罩
                            document.body.removeChild(btn.el_temp);
                            formatWin.el.dom.querySelector(".x-tool-close").style.display = "block";//顯示win【x】
                            //ajax
                            var sortStr = formatStore.getRange().map(r => r.get('sn')).join(',');
                            if (sort_temp !== sortStr) {
                                Ext.Ajax.request({
                                    method: 'POST', url: subHandler.subController + '&action=sortFormat',
                                    params: { sn: sortStr },
                                    success: function (result, request) {
                                        if (result.responseText == 'ok') {
                                            win_refreshData('sort', null);//刷新資料
                                            Ext.ux.TopMsg.msg('提醒', '<span style="color:green">排序成功!</span>', 5, 100);
                                            sort_temp = sortStr;//將臨時排序取代
                                        } else {
                                            Ext.Msg.alert('Error', '[sortFormat]失敗:' + result.responseText);
                                        }
                                    },
                                    failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                                });
                            }
                        }
                    },
                },
                '->',
                {
                    xype: 'button', itemId: '', text: '新增', iconCls: 'add', tooltip: '欄位新增',
                    handler: function (btn) {
                        formatGrid.recordMaker = formatGrid.recordMaker || new Ext.data.Record.create(formatStore.reader.meta.fields);
                        var newRecord = new formatGrid.recordMaker({
                            sn: 0, fSn: formatWin.record.get('sn'), param: "", title: "", typeSn: "1",
                        });
                        formatGrid.stopEditing();
                        formatStore.insert(0, newRecord);
                        formatGrid.startEditing(0, formatGrid.getColumnModel().findColumnIndex('param'));
                    }
                }
            ],
            listeners: {
                afterrender(_this) {
                    formatGrid.view.dragZone.lock();//鎖上不讓更改
                    new Ext.dd.DropTarget(formatGrid.view.scroller.dom, { //此表
                        ddGroup: ['formatDDGroup'], //可移動至的表
                        notifyDrop(ddSource, e, data) { //其他表項目在此表 放開時
                            var view = formatGrid.view;
                            //*關閉補助線  !!view.getRow(formatGrid.rowDDLine).style為了比較表格的顏色
                            if (formatGrid.rowDDLine !== null) view.getRow(formatGrid.rowDDLine).style['border-top'] = '';
                            view.getRow(formatStore.getCount() - 1).style['border-bottom'] = '';
                            //*排序
                            var selRecords = formatGrid.getSelectionModel().getSelections();//*選擇的那欄的資料
                            selRecords.sort((r1, r2) => formatStore.indexOf(r1) > formatStore.indexOf(r2)); //*照rowIndex排序
                            //*計算應插入的index = 目標rI - (選擇rI小於目標rI的數量)
                            var selRowsIndex = selRecords.map(r => formatStore.indexOf(r));
                            var targetRowIndex = view.findRowIndex(e.target);
                            formatStore.remove(selRecords);//*移除選擇的那欄的資料
                            var insertIndex = (targetRowIndex !== false) ?
                                targetRowIndex - (selRowsIndex.filter(sI => sI < targetRowIndex).length) :
                                formatStore.getCount();
                            formatStore.insert(insertIndex, selRecords);//*插入選擇的那欄的資料
                        },
                        notifyOver(ddSource, e, data) { //*其他表項目在此表 移過時
                            var view = formatGrid.view;
                            //顯示補助移動線
                            var targetRowIndex = view.findRowIndex(e.target);
                            if (targetRowIndex !== false) {
                                view.getRow(formatStore.getCount() - 1).style['border-bottom'] = ''; //關閉最下層line
                                if (formatGrid.rowDDLine !== targetRowIndex) { //拖曳補助線換位置
                                    if (formatGrid.rowDDLine !== null) view.getRow(formatGrid.rowDDLine).style['border-top'] = '';//*&& !!view.getRow(formatGrid.rowDDLine).style 可以不用
                                    view.getRow(targetRowIndex).style['border-top'] = '3px red dotted';//*拖曳時表格變色
                                }
                                formatGrid.rowDDLine = targetRowIndex;
                            } else {
                                if (formatGrid.rowDDLine !== null) view.getRow(formatGrid.rowDDLine).style['border-top'] = ''; //*關閉中間層line    //*&& !!view.getRow(formatGrid.rowDDLine).style
                                formatGrid.rowDDLine = null;
                                view.getRow(formatStore.getCount() - 1).style['border-bottom'] = '3px red dotted';//*拖離開此表的時候border的顏色
                            }
                            return this.dropAllowed;
                        },
                    });
                },
                afteredit: function (e) {
                    var record = e.record;
                    var sn = record.get('sn');
                    //檢查值是否為空值
                    if (!e.value) {
                        Ext.ux.TopMsg.msg('提醒', '<span style="color:red">編輯失敗:不可為空值!</span>', 3, 180);
                        record.set(e.field, e.originalValue);
                    } else {//新增修改AJAX
                        editFormatAjax(sn, e);
                    }
                },
                rowcontextmenu: function (grid, rI, e) {
                    e.preventDefault();
                    var formatSM = grid.getSelectionModel();
                    formatSM.selectRow(rI);
                    var record = formatSM.getSelected(); //取得record
                    if (record) {
                        new Ext.menu.Menu({
                            items: [
                                {
                                    xype: 'button', itemId: 'delBtn', text: '刪除', iconCls: 'del',
                                    handler: function (b) {
                                        Ext.Msg.show({
                                            title: '確認', iconCls: 'info', width: 250,
                                            buttons: Ext.Msg.YESNO, icon: Ext.MessageBox.QUESTION,
                                            msg: `<font style="color:blue";>欄位：【${record.get("param")}】<br>` +
                                                `你確定要刪除?<br>此動作無法復原。</font>`,
                                            fn: function (btn) {
                                                if (btn == 'yes') {
                                                    Ext.Ajax.request({
                                                        method: 'POST', url: subHandler.subController + '&action=delFormat',
                                                        params: { sn: record.get("sn") },
                                                        success: function (result, request) {
                                                            if (result.responseText == 'ok') {
                                                                formatGrid.getStore().remove(record);
                                                                win_refreshData('delete', null);
                                                                selectedModifyRecord();
                                                                Ext.ux.TopMsg.msg('通知', '<span style="color:green">刪除成功</span>', 2, 100);
                                                            } else {
                                                                Ext.Msg.alert('Error', '刪除失敗:' + result.responseText);
                                                            }
                                                        },
                                                        failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                                                    });
                                                }
                                            }
                                        });
                                    }
                                }
                            ],
                        }).showAt(e.getXY());
                    }
                }
            }
        });

        //* ---左側內容start--- *//
        //  (左側上方Grid & store)-QRcodeGrid
        var QRcodeStore = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({ url: `${subHandler.subController}&action=loadData&dummy=${new Date().getTime()}`, method: 'POST' }),
            reader: new Ext.data.JsonReader({
                totalProperty: 'total', root: 'data',
                fields: [
                    { name: 'sn', type: 'int' },//sn
                    { name: 'type', type: 'int' },//編號
                    { name: 'stateSn', type: 'int' },//狀態
                    { name: 'title', type: 'string' },//主題
                    { name: 'format', type: 'string' },//格式
                    { name: 'depSn', type: 'int' },//列印權責單位
                    { name: 'depName', type: 'string' },//列印權責單位(中文)=>初始化渲染用
                    { name: 'prinUSn', type: 'string' },//窗口
                    { name: 'prinName', type: 'string' },//窗口(中文)=>初始化渲染用
                    { name: 'example', type: 'string' },//範例
                    { name: 'remark', type: 'string' },//說明
                    { name: 'setDate', type: 'date' },//設定日期
                    { name: 'setName', type: 'string' }//設定人員
                ]
            }),
            listeners: { load: function (_this, records, object) { } }
        });
        var QRcodeGrid = new Ext.grid.EditorGridPanel({
            title: '', iconCls: '', border: true, layout: 'fit', autoExpandColumn: 9, region: 'center',
            loadMask: true, stripeRows: true, columnLines: true, trackMouseOver: true, enableColumnMove: false, //讀取圖案,條紋列顏色,分隔線,滑鼠滑過,欄位拖拉
            view: new Ext.grid.GridView({ markDirty: false }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: true, moveEditorOnEnter: false,
                listeners: {
                    rowselect(_this, rI, r) {
                        //*--自身設定(左上)--
                        //*--favoriteGrid相關設定(右上)--
                        favoriteGrid.getSelectionModel().clearSelections();//清除我的最愛選取
                        favoriteStore.setBaseParam('sn', r.get('sn'));
                        favoriteStore.load();
                        //*--JSONPanel編輯器相關設定(左下)--
                        var recordObj = JSON.parse(r.get('example'));
                        var jsonObj = Object.assign({ "type": r.get('type').toString() }, recordObj);
                        JsonEditor.set(jsonObj);
                        if (JsonEditor.getMode() == 'form') JsonEditor.node.childs.forEach(data => data.type = "string");
                        //*--QRcodePanel相關設定(右下)--
                        QRcodePanel.setTitle(`QRcode條碼預覽`);
                        QRcodePanel.update(
                            `<div style="display: flex;justify-content: center; align-items:center; height:100%;">` +
                            `${printQRcodeImage()}` +
                            `</div>`
                        );
                        //其他設定
                        otherSetting(true, r, 'QRcodeGrid');
                    }
                }
            }),
            store: QRcodeStore,
            cm: new Ext.grid.ColumnModel({
                // defaults: { align: 'center', sortable: true, menuDisabled: true,/*fixed:true,*/ },
                columns: [
                    { hidden: true, header: 'sn', dataIndex: 'sn' },
                    {
                        header: '編號(type)', dataIndex: 'type', width: 80, align: 'center', sortable: true, msgTarget: 'side', editor: new Ext.form.NumberField({
                            validator: function (value) {
                                if (/^\+?[1-9][0-9]*$/.test(value) || value == "") {
                                    return true;
                                } else {
                                    return '請輸入正整數';
                                }
                            },
                            listeners: {
                                // 離開焦點時(按enter也會), 如果是新增的時候(sn=0) && (沒輸入 or 輸入不是正整數), 代表存入失敗, 移除此筆record
                                //                             編輯的時候(sn!=0) , 不要移除此筆record
                                blur: function (_this) {
                                    var record = _this.gridEditor.record;
                                    var value = _this.getValue()
                                    if (record.get('sn') === 0 && (value === '' || !(/^\+?[1-9][0-9]*$/.test(value)))) {
                                        QRcodeStore.remove(record);
                                    }
                                },
                                specialkey(_this, e) {
                                    if (e.getKey() === e.ENTER) {
                                        if (_this.getValue() && !(/^\+?[1-9][0-9]*$/.test(_this.getValue()))) {
                                            Ext.ux.TopMsg.msg('提醒', '<span style="color:red">新增失敗<br>請輸入正整數</span>', 5, 120);
                                            return false;
                                        }
                                    }
                                }
                            }
                        }),
                    },
                    {
                        header: '狀態', dataIndex: 'stateSn', align: 'center', width: 50, editor: new Ext.form.ComboBox({
                            tpl: '<tpl for="."><div class="x-combo-list-item" ext:qtip="{title} ({sn})">{title} </div></tpl>',
                            typeAhead: true, triggerAction: 'all', editable: false,
                            lazyRender: true, mode: 'local',
                            listWidth: 70, listClass: 'x-combo-list-small',
                            valueField: 'sn', displayField: 'title',
                            store: stateStore,
                            listeners: {
                                expand: function (combo) {
                                    stateStore.filterBy(r => r.get('sn') < 2);
                                }
                            }
                        }),
                        renderer: (v, m, r, rI, cI, s) => v == '1' ? '啟用' : '停用'
                    },
                    { header: '主題', dataIndex: 'title', width: 130, align: 'center', editor: new Ext.form.TextField(), renderer: (v, m, r, rI, cI, s) => `<span ext:qwidth='auto' ext:qtip="${v}">${v}</span>` },
                    {
                        header: '格式(欄位點擊兩下設定)', dataIndex: 'format', width: 250, editor: new Ext.form.TextField(), renderer: (v, m, r, rI, cI, s) => v.replace(/\,/g, "<br>")
                    },
                    {
                        header: '列印權責單位', dataIndex: 'depSn', width: 100, renderer: (v, m, r, rI, cI, s) => r.get('depName'),
                        editor: new Ext.ux.triggerTree({
                            dataUrl: "/system/CommAjax.php", baseParams: { action: 'loadDeptree' }, isPath: false, width: 100, treeEmptyText: "'輸入部門名稱或代碼後按Enter'",
                            listeners: { blur(_this) { editor_temp = _this.newValue; } }, //紀錄部門名稱
                        }),
                    },
                    { hidden: true, header: '列印權責單位(中文)(隱)', dataIndex: 'depName', },
                    {
                        header: '窗口', dataIndex: 'prinUSn', width: 50,
                        renderer: (v, m, r) => `<span isQtip=false onmouseover="if(typeof qtipMember!=='undefined')qtipMember(this,${v});">${r.get('prinName')}</span>`, //tip顯示電話
                        editor: new Ext.ux.winDepMember({
                            listeners: { blur(_this) { editor_temp = _this.uName; } } //紀錄姓名
                        })
                    },
                    { hidden: true, header: '窗口(中文)(隱)', dataIndex: 'prinName', },
                    // { header: '範例', dataIndex: 'example', width: 130, renderer: (v, m, r) => '點擊後下方預覽' },
                    { header: '範例(點擊選項後，下方預覽)', dataIndex: 'example', width: 130, align: 'center', renderer: (v, m, r) => v },
                    { header: '說明', dataIndex: 'remark', width: 150, editor: new Ext.form.TextArea(), renderer: (v, m, r, rI, cI, s) => "<span ext:qwidth='auto' ext:qtip='" + v + "'>" + v + "</span>" },
                    {
                        header: '設定日期', dataIndex: 'setDate', width: 130, renderer: function (v, m, r, rI, cI, s) {
                            var qData = Ext.util.Format.date(new Date(v), 'Y-m-d H:i:s');
                            return "<span ext:qwidth='auto' ext:qtip='" + qData + "'>" + qData + "</span>";
                        }
                    },
                    { header: '設定人員', dataIndex: 'setName', width: 60 },
                ],
            }),
            tbar: [
                '篩選：',
                {
                    xtype: 'textfield', disabled: false, itemId: 'searchField', emptyText: '可輸入主題或編號(enter查詢)', width: 180,
                    blankText: '', msgTarget: 'side',
                    listeners: {
                        specialkey(_this, e) {
                            if (e.getKey() === e.ENTER) {
                                var value = _this.getValue();
                                if (!value) {
                                    resetData('specialkey_enter');
                                } else {
                                    QRcodeStore.baseParams = { keyWord: value, stateSn: stateValue };
                                    QRcodeStore.load();
                                }
                            }
                        }
                    }
                }, '-',
                '狀態：',
                {
                    xtype: 'combo',
                    width: 80, selectOnFocus: true, tpl: '<tpl for="."><div class="x-combo-list-item" ext:qtip="{title} ({sn})">{title} </div></tpl>',
                    typeAhead: true, triggerAction: 'all', value: 1, itemId: 'stateCombe', forceSelection: true, editable: false, lazyRender: true, mode: 'local', valueField: 'sn', displayField: 'title',
                    remoteSort: true, autoLoad: true, store: stateStore,
                    listeners: {
                        select: function (combo, record, index) {
                            comboValue = combo.getValue();
                            if (comboValue != stateValue) {
                                stateValue = parseInt(comboValue);
                                QRcodeStore.setBaseParam('stateSn', stateValue);
                                QRcodeStore.load();
                                resetData('stateCombe');
                            }
                        },
                        expand: function (combe) {
                            stateStore.filterBy(r => r.get('sn') <= 2);
                        }
                    }
                },
                '->',
                {
                    xype: 'button', itemId: '', text: '新增', iconCls: 'add', tooltip: '主題新增',
                    handler: function (btn) {
                        QRcodeStore.recordMaker = QRcodeStore.recordMaker || new Ext.data.Record.create(QRcodeStore.reader.meta.fields);
                        var newRecord = new QRcodeStore.recordMaker({
                            sn: 0, type: "", stateSn: 1, title: '', format: "",
                            depSn: 0, depName: "", prinUSn: 0, prinName: "", example: "", remark: "",
                            setDate: new Date(), setName: initParams.uName,
                        });
                        QRcodeGrid.stopEditing();
                        QRcodeStore.insert(0, newRecord);
                        QRcodeGrid.startEditing(0, QRcodeGrid.getColumnModel().findColumnIndex('type'));
                    }
                }, '-',
                {
                    xype: 'button', text: '刷新', iconCls: 'refresh', itemId: 'refreshBtn', tooltip: '編號由小到大排序',
                    handler: function (btn) {
                        QRcodeGrid.getTopToolbar().get('searchField').setValue("");
                        resetData('refreshBtn');
                    }
                },
            ],
            listeners: {
                beforeedit: function (e) {
                    var record = e.record;
                    var field = e.field;
                    if (field == 'format') {
                        openFormatWin(record);
                        return false;
                    }
                },
                afteredit: function (e) {
                    var record = e.record;
                    var sn = record.get('sn');
                    //檢查值是否為空值
                    if (e.field == 'type' && !e.value) {
                        Ext.ux.TopMsg.msg('提醒', '<span style="color:red">編輯失敗:不可為空值!</span>', 3, 180);
                        record.set(e.field, e.originalValue);
                    } else {//新增修改AJAX
                        rowEditAjax(sn, e);
                    }
                },
                rowcontextmenu: function (grid, rI, e) {
                    e.preventDefault();
                    var QRcodeSM = grid.getSelectionModel();
                    QRcodeSM.selectRow(rI);
                    var record = QRcodeSM.getSelected(); //取得record
                    if (record) {
                        new Ext.menu.Menu({
                            items: [
                                {
                                    xype: 'button', itemId: 'delBtn', text: '刪除', iconCls: 'del',
                                    handler: function (b) {
                                        Ext.Msg.show({
                                            title: '確認', iconCls: 'info', width: 250,
                                            buttons: Ext.Msg.YESNO, icon: Ext.MessageBox.QUESTION,
                                            msg: `<font style="color:blue";>主題名稱：【${record.get("title")}】<br>` +
                                                `你確定要刪除?<br>此動作無法復原。</font>`,
                                            fn: function (btn) {
                                                if (btn == 'yes') {
                                                    Ext.Ajax.request({
                                                        method: 'POST', url: subHandler.subController + '&action=delData',
                                                        params: { sn: record.get("sn") },
                                                        success: function (result, request) {
                                                            if (result.responseText == 'ok') {
                                                                QRcodeGrid.getStore().remove(record);
                                                                //下方編輯器設定
                                                                JsonEditor.set({}); //清空編輯器
                                                                JSONPanel.getTopToolbar().get('jsonTitle').setText(`目前選取主題：<span style="color:red;border:solid 2px yellow; padding:2px;">尚未選取主題</span>`);
                                                                //我的最愛相關設定(favoriteGrid)
                                                                favoriteStore.setBaseParam('sn', "");
                                                                favoriteStore.load();
                                                                favoriteGrid.setTitle(`我的最愛( <span style="color:red;border:solid 2px yellow; padding:2px;">尚未選取主題</span> )`);
                                                                Ext.ux.TopMsg.msg('通知', '<span style="color:red">刪除成功</span>', 1, 100);
                                                            } else {
                                                                Ext.Msg.alert('Error', '刪除失敗:' + result.responseText);
                                                            }
                                                        },
                                                        failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                                                    });
                                                }
                                            }
                                        });
                                    }
                                }
                            ],
                        }).showAt(e.getXY());
                    }
                }
            }
        });
        //  (左側下方Panel)-JSON編輯器
        var JSONPanel = new Ext.Panel({
            region: 'south', border: true, width: 700, height: document.body.offsetHeight / 2, collapsible: false, split: true,
            tbar: [
                { xtype: 'tbtext', itemId: 'jsonTitle', text: '目前選取主題：<span style="color:red">未選取</span>' }, '-',
                {
                    xype: 'button', itemId: 'favoriteBtn', text: '設為最愛', iconCls: 'shawn-star', tooltip: '',
                    handler: function (btn) {
                        var pass = checkEdit(JsonEditor.getText());
                        //5.結果處理
                        if (!pass) return;
                        Ext.MessageBox.prompt('設為最愛', "此為QRcode備註【可為空值】</li><hr>", function (btn, remark) {
                            if (btn != 'ok') return;
                            //找出input的fSn
                            var jsonObj = JsonEditor.get();//編輯器內容
                            var recordIndex = QRcodeStore.findBy(r => r.get('type') == jsonObj["type"]);
                            var fSn = QRcodeStore.getAt(recordIndex).get('sn');
                            Ext.Ajax.request({
                                method: 'POST', url: subHandler.subController + '&action=addExample',
                                params: { fSn: fSn, example: JsonEditor.getText(), remark: remark },
                                success: function (result, request) {
                                    var resultArr = result.responseText.split(',');
                                    var resultType = resultArr[0], newSn = resultArr[1];
                                    if (resultType != 'okAdd') {
                                        Ext.Msg.alert('Error', '[新增最愛]失敗:' + result.responseText);
                                        return;
                                    }
                                    //選回篩選種類
                                    favoriteStore.setBaseParam('sn', fSn);
                                    favoriteStore.load({
                                        callback: () => {
                                            favoriteGrid.getSelectionModel().selectFirstRow();
                                            Ext.ux.TopMsg.msg('提醒', '<span style="color:green">新增成功!</span>', 5, 100);
                                        }
                                    });
                                },
                                failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                            });
                        });
                    }
                }, '-',
                {
                    xype: 'button', itemId: 'produceBtn', text: '產生QRcode', iconCls: 'qrcode', tooltip: '',
                    subject: '',//自訂變數
                    handler: function (btn) {
                        var pass = true;
                        if (!isJson(JsonEditor.getText())) {
                            pass = false;
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:red">產生失敗,JSON格式有誤請確認!</span>', 5, 230);
                        }
                        if (pass) {
                            //清除我的最愛選取
                            favoriteGrid.getSelectionModel().clearSelections();
                            //製作QRcode
                            var obj = JsonEditor.get();
                            var str = Object.keys(obj).map(key => `"<p style="color:red">${key}</p>":"<p style="color:blue">${obj[key]}</p>"`).join(',');
                            QRcodePanel.update(
                                `<div class="tipContainer">` +
                                `<div class="tip-top">{${str}}</div>` +
                                `${printQRcodeImage(JsonEditor.getText())}` +
                                `</div>`
                            );
                            QRcodePanel.setTitle(`QRcode條碼預覽 (${btn.subject}-條碼)`);
                            Ext.ux.TopMsg.msg('提醒', '<span style="color:blue">已產生新的QRcode,請確認</span>', 5, 200);
                        }
                    }
                }, '-',
                {
                    xype: 'button', itemId: 'copyBtn', text: '複製編輯器文字', iconCls: 'copy', tooltip: '',
                    handler: function (btn) {
                        var el = document.createElement('textarea');
                        el.value = JsonEditor.getText();
                        document.body.appendChild(el);
                        el.select();
                        document.execCommand("Copy");
                        document.body.removeChild(el);
                        Ext.ux.TopMsg.msg('通知', '<span style="color:green">複製成功!</span>', 1, 100);
                    }
                },
            ],
            html: `<div id="${mainId}_jsoneditor"></div>`,
            listeners: {
                afterrender: function (_this) {
                    var container = document.getElementById(`${mainId}_jsoneditor`);
                    var options = {
                        mode: 'form', search: false,
                        modes: ['code', 'form'], // allowed modes('text', 'tree', 'view', 'preview')
                        onModeChange: function (newMode, oldMode) {
                            if (newMode == 'code') {
                                Ext.Msg.show({
                                    title: '提醒', iconCls: 'alert', width: 220, buttons: Ext.Msg.OK,
                                    msg: `<font style='color:blue';>【code模式下】不攸關選取的主題<br>可以隨意貼上!</font>`,
                                });
                            }
                            if (newMode == 'form') JsonEditor.node.childs.forEach(data => data.type = "string");
                        },
                        onEditable: function (node) {
                            if (node.field == 'type') return { field: false, value: false };//type不能編輯
                            return { field: false, value: true };
                        },
                    }
                    // create the editor
                    JsonEditor = new JSONEditor(container, options);
                }
            }

        });

        //* ---右側內容start--- *//
        //  (右側上方Grid & store)-favoriteGrid
        var favoriteStore = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({ url: `${subHandler.subController}&action=loadExample&dummy=${new Date().getTime()}`, method: 'POST' }),
            reader: new Ext.data.JsonReader({
                totalProperty: 'total', root: 'data',
                fields: [
                    { name: 'sn', type: 'int' },
                    { name: 'fSn', type: 'int' },//QRcodeStore的sn
                    { name: 'title', type: 'string' },//主題
                    { name: 'example', type: 'string' },//資料內容
                    { name: 'remark', type: 'string' },//備註
                ]
            }),
            listeners: { load: function (_this, records, object) { } }
        });
        var favoriteGrid = new Ext.grid.EditorGridPanel({
            title: '我的最愛( <span style="color:red">未選取主題</span> )', iconCls: 'shawn-star', border: false, layout: 'fit', autoExpandColumn: 3, region: 'center',
            loadMask: true, stripeRows: true, columnLines: true, trackMouseOver: true, enableColumnMove: false, //讀取圖案,條紋列顏色,分隔線,滑鼠滑過,欄位拖拉
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: true, moveEditorOnEnter: false,
                listeners: {
                    rowselect(_this, rI, r) {
                        //*--QRcodeGrid相關設定(左上)--
                        QRcodeGrid.getSelectionModel().clearSelections();//清除QRcodeGrid選取
                        //*--自身設定(右上)--
                        var title = r.get('title') || '未設定主題';
                        favoriteGrid.setTitle(`我的最愛( 單：<span style="color:red;border:solid 2px yellow; padding:2px;">${title}</span> )`);
                        //*--JSONPanel編輯器相關設定(左下)--
                        var recordObj = JSON.parse(r.get('example'));
                        JsonEditor.set(recordObj);
                        if (JsonEditor.getMode() == 'form') JsonEditor.node.childs.forEach(data => data.type = "string");
                        //*--QRcodePanel相關設定(右下)--
                        var remark = r.get('remark') || '無填寫備註';
                        QRcodePanel.setTitle(`QRcode條碼預覽 (我的最愛【單:${r.get('title')}】- <span style="color:red;border:solid 2px yellow; padding:2px;">${remark}</span>)`);
                        var obj = JsonEditor.get()
                        var str = Object.keys(obj).map(key => `"<p style="color:red">${key}</p>":"<p style="color:blue">${obj[key]}</p>"`).join(',');
                        QRcodePanel.update(
                            `<div class="tipContainer">` +
                            `<div class="tip-top">{${str}}</div>` +
                            `${printQRcodeImage(r.get('example'))}` +
                            `</div>`
                        );
                        //其他設定
                        otherSetting(true, r, 'favoriteGrid');
                    }
                }
            }),
            store: favoriteStore,
            cm: new Ext.grid.ColumnModel({
                // defaults: { align: 'center', sortable: true, menuDisabled: true,/*fixed:true,*/ },
                columns: [
                    { hidden: true, header: 'sn', dataIndex: 'sn' },
                    { hidden: true, header: 'QRcodeGrid的sn', dataIndex: 'fSn', },
                    { header: '主題', dataIndex: 'title', align: 'center', width: 90, renderer: (v) => `<span ext:qtip="${v}" ext:qwidth='auto' >${v}</span>` },
                    {
                        header: '資料內容', dataIndex: 'example', editor: new Ext.form.TextArea(), renderer: (v) => {
                            var qtip = 'json格式有誤';
                            if (!!isJson(v)) {
                                var valueObj = JSON.parse(v);
                                var qtip = Object.keys(valueObj).map(key => {
                                    var value = valueObj[key];
                                    return `<span color:blue>${key}</span>:${(!!value) ? value : 'null'}`;
                                }).join('<br>');
                            }
                            return `<span ext:qtip="${qtip}" ext:qwidth='auto' >${v}</span>`
                        }
                    },
                    { header: '備註', dataIndex: 'remark', width: 150, editor: new Ext.form.TextField() },
                ],
            }),
            tbar: ['->',
                {
                    xype: 'button', itemId: 'filterClearBtn', text: '顯示全部主題', iconCls: 'list', tooltip: '',
                    handler: function (btn) {
                        QRcodeGrid.getSelectionModel().clearSelections();
                        resetData('filterClearBtn');
                    }
                }
            ],
            listeners: {
                afteredit: function (e) {
                    var record = e.record;
                    if (e.field == 'example') {
                        var pass = checkEdit(record.get('example'));
                        if (pass) {
                            afterEditExample(e);
                            //編輯器處理
                            JsonEditor.setText(record.get('example'));
                            var obj = JSON.parse(record.get('example'));
                            var str = Object.keys(obj).map(key => `"<p style="color:red">${key}</p>":"<p style="color:blue">${obj[key]}</p>"`).join(',');
                            QRcodePanel.update(
                                `<div class="tipContainer">` +
                                `<div class="tip-top">{${str}}</div>` +
                                `${printQRcodeImage(record.get('example'))}` +
                                `</div>`
                            );
                        } else {
                            record.set(e.field, e.originalValue);
                            record.commit();
                        }
                    } else if (e.field == 'remark') {
                        afterEditExample(e);
                        var remark = e.value || '無填寫備註';
                        QRcodePanel.setTitle(`QRcode條碼預覽(我的最愛【${record.get('title')}】- <span style="color:red;border:solid 2px yellow; padding:2px;" > ${remark}</span >)`);
                    }
                },
                rowcontextmenu: function (grid, rI, e) {
                    e.preventDefault();
                    var favoriteSM = grid.getSelectionModel();
                    favoriteSM.selectRow(rI);
                    var record = favoriteSM.getSelected(); //取得record
                    if (record) {
                        new Ext.menu.Menu({
                            items: [
                                {
                                    xype: 'button', itemId: 'delBtn', text: '刪除', iconCls: 'del',
                                    handler: function (b) {
                                        Ext.Msg.show({
                                            title: '確認', iconCls: 'info', width: 250,
                                            buttons: Ext.Msg.YESNO, icon: Ext.MessageBox.QUESTION,
                                            msg: `<font style="color:blue";>刪除主題：${record.get("title")}<hr> 備註為：【${record.get("remark")}】<br>` +
                                                `你確定要刪除?<br>此動作無法復原。</font>`,
                                            fn: function (btn) {
                                                if (btn == 'yes') {
                                                    Ext.Ajax.request({
                                                        method: 'POST', url: subHandler.subController + '&action=delExample',
                                                        params: { sn: record.get("sn") },
                                                        success: function (result, request) {
                                                            if (result.responseText == 'ok') {
                                                                favoriteGrid.getStore().remove(record);
                                                                //清空編輯器
                                                                JsonEditor.set({});
                                                                //右下角圖案
                                                                QRcodePanel.update(
                                                                    `<div style="display: flex;justify-content: center; align-items:center; height:100%;">` +
                                                                    `${printQRcodeImage()}` +
                                                                    `</div>`
                                                                );
                                                                //其他設定
                                                                otherSetting(false, null);
                                                                Ext.ux.TopMsg.msg('通知', '<span style="color:green">刪除成功</span>', 2, 100);
                                                            } else {
                                                                Ext.Msg.alert('Error', '刪除失敗:' + result.responseText);
                                                            }
                                                        },
                                                        failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                                                    });
                                                }
                                            }
                                        });
                                    }
                                }
                            ],
                        }).showAt(e.getXY());
                    }
                }
            }
        });

        //  右側下方Panel(放置QRcode)
        var QRcodePanel = new Ext.Panel({
            title: 'QRcode條碼預覽', border: false, height: 450, region: 'south',
            html: `<div style="display: flex;justify-content: center; align-items:center; height:100%;">` +
                `${printQRcodeImage()}` +
                `</div>`
        });

        //* leftPanel(左側Panel) *//
        var leftPanel = new Ext.Panel({
            region: 'center', border: false, split: true, layout: 'border',
            items: [QRcodeGrid, JSONPanel],

        });
        //* rightPanel(右側Panel) *//
        var rightPanel = new Ext.Panel({
            region: 'east', border: true, width: 550, collapsible: false, split: true, //minSize: 100, maxSize: 200,
            layout: 'border', minSize: 400,
            // defaults: {collapsible: true, split: true, },
            items: [favoriteGrid, QRcodePanel],
        });
        //* mainContainer *//
        var mainContainer = new Ext.Panel({
            layout: 'border', border: false,
            items: [leftPanel, rightPanel],
        });
        QRcodeStore.load();
        favoriteStore.load();
        subHandler.doLayout(mainContainer)
    }
    var subHandler = new getHandler();
    Ext.ux.Loader.load([
        'ux_triggerTree', 'ux_winDepMember',
        subHandler.subFolder + '/jsonEditor/jsoneditor-minimalist.min.js',
        subHandler.subFolder + 'shawn.css',
        subHandler.subFolder + '/jsonEditor/jsoneditor.min.css'
    ], function () {
        subHandler.initParam(layoutMain);
    }, subHandler);
}();