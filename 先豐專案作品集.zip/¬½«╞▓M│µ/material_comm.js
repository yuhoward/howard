//篩選、新增視窗共用 
material_comm = function (subHandler) {
    var mainId = subHandler.mainId || subHandler.parentId;
    var self = this;
    //* 檢查必填欄位 *//
    //requiredArr=>必填欄位[],fieldName=>欄位名稱
    self.checkRequiredField = (requiredArr, fieldName) => requiredArr.indexOf(fieldName) >= 0;
    //* 篩選tooltip *//
    this.setTooltip = function (element, type) {
        var tipVal = "";
        switch (type) {
            case 'any':
                tipVal = '請使用<font color="red">"**"</font>可進行模糊查詢(ex: 1060<font color="red">**</font>)';
                break;
            case 'range':
                tipVal = '請使用<font color="red">"~"</font>可進行區間查詢(ex: 30<font color="red">~</font>60)';
                break;
            case 'material':
                tipVal = '篩選時將會排除<font color="red">"材料編號"</font>條件進行篩選,以確保規格唯一性'
                break;
        }
        var tip = new Ext.ToolTip({
            target: element.id, html: tipVal, anchor: 'left',
            dismissDelay: 0, showDelay: 0, autoHide: false, autoWidth: true,
        });
        element.getEl().on('mouseover', function () { tip.show(); });
        element.getEl().on('mouseleave', function () { tip.hide(); });
    }
    //* 建立新的ComboS  *//
    //createComboS(欄位中文,欄位英文,欄位的store,開啟窗[filter->篩選,add->新增])
    this.createComboS = function (fieldLabel, fieldName, store, formType) {
        return new Ext.ux.comboS({
            hidden: true, xtype: "combo", lazyRender: true, typeAhead: true, width: 100, lastQuery: "",
            triggerAction: 'all', mode: 'local', editable: false, emptyText: '全部顯示',
            multiSelect: true, name: 'title', valueField: 'sn', displayField: 'title',
            tpl: '<tpl for="."><div class="x-combo-list-item" ext:qtip="{title}{remark}">{title} </div></tpl>',
            itemId: 'comboS',
            //自訂參數
            fieldLabel: fieldLabel,//中文名稱
            fieldName: fieldName,//英文名稱
            store: store,
            listeners: {
                expand: function (combo) {
                    combo.getStore().filterBy(r => r.get('sn') > 0);
                    (function () {
                        //將原始值塞回
                        originalValueList = combo.oldValueArray;//紀錄上次選取值
                        if (!!originalValueList) {
                            //filter原因:switchCombo會setValue("")清空，但originalValueList會取清空的空值，故要篩掉
                            originalValueList = originalValueList.filter((value) => value !== "");
                            combo.setValue(originalValueList);
                        }
                    }).defer(100);
                },

            }
        });
    }
    //* 建立新的Combo(新增、篩選的)  *//
    //createCombo(欄位中文,欄位英文,欄位的store,formType=>add/filter,isCandidate是否為候選項欄位,editable->combo是否可編輯,specialkey鍵盤操作處理,validator驗證處理)
    this.createCombo = function (fieldLabel, fieldName, store, formType, isCandidate, editable, specialkey, validator) {
        return new Ext.form.ComboBox({
            hidden: false, lazyRender: true, typeAhead: false, autoSelect: false, lastQuery: "",
            triggerAction: 'all', mode: 'local', emptyText: '全部顯示',
            name: 'title', valueField: 'sn', displayField: 'title', listClass: 'x-combo-list-small',
            tpl: '<tpl for="."><div class="x-combo-list-item" ext:qtip="{title} {remark}({sn})">{title}</div></tpl>',
            editable: editable, itemId: 'combo',
            store: store,
            width: (formType == 'add') ? 180 : 100,
            fieldLabel: fieldLabel,//中
            validator: (formType == 'add') ? validator : null,//驗證功能
            //自訂參數
            fieldName: fieldName,//英
            formType: formType,//建立時表單類型
            isCandidate: isCandidate,//=>getAddResult使用
            doQuery: function (q, forceAll) {
                q = Ext.isEmpty(q) ? '' : q;
                var qe = {
                    query: q,
                    forceAll: forceAll,
                    combo: this,
                    cancel: false
                };
                if (this.fireEvent('beforequery', qe) === false || qe.cancel) {
                    return false;
                }
                q = qe.query;
                forceAll = qe.forceAll;
                if (forceAll === true || (q.length >= this.minChars)) {
                    if (this.lastQuery !== q) {
                        this.lastQuery = q;
                        if (this.mode == 'local') {
                            this.selectedIndex = -1;
                            if (forceAll) {
                                this.store.clearFilter();
                            } else {
                                //改寫
                                var isRequiredField = self.checkRequiredField(store.requiredArr, fieldName);
                                if (!q) {
                                    this.store.filterBy(function (record) {
                                        if (formType == 'filter') {
                                            return record.get('sn') > 0 || record.get('title') == '全部顯示';
                                        } else if (formType == 'add' && isRequiredField) {
                                            return record.get('sn') > 0;
                                        } else if (formType == 'add' && !isRequiredField) {
                                            return record.get('sn') > 0 || record.get('title') == '　';
                                        }
                                    });
                                } else {
                                    this.store.filter(this.displayField, q);
                                }
                            }
                            this.onLoad();
                        } else {
                            this.store.baseParams[this.queryParam] = q;
                            this.store.load({
                                params: this.getParams(q)
                            });
                            this.expand();
                        }
                    } else {
                        this.selectedIndex = -1;
                        this.onLoad();
                    }
                }
            },
            listeners: {
                beforerender: function (combo) {
                    //combo欄位寬度調整
                    // 基板
                    if (["THKUnitSn", "widthUnitSn", "lengthUnitSn", "LWUnitSn", "toleranceUnitSn", "thickness_unit", "thicknessType", "core_widthUnitSn", "core_lengthUnitSn"].indexOf(fieldName) >= 0) {
                        combo.setWidth(185);
                    }
                    if (formType == 'add' && ["o_foilType_f", "o_foilType_s", "o_model"].indexOf(fieldName) >= 0) {
                        combo.setWidth(149);
                    }
                    //PP
                    if (["width_unit", "long_unit"].indexOf(fieldName) >= 0) {
                        combo.setWidth(174);
                    }
                    //金屬
                    if (["toleranceUnitSn", "LWUnitSn"].indexOf(fieldName) >= 0) {
                        combo.setWidth(180);
                    }
                    //膠
                    if (["THKUnitSn", "widthUnitSn", "lengthUnitSn"].indexOf(fieldName) >= 0) {
                        combo.setWidth(180);
                    }
                    //乾濕膜

                },
                render: function (combo) {
                    if (formType == 'filter' && isCandidate) { self.setTooltip(combo, 'any'); }
                },
                expand: function (combo) {
                    var isRequiredField = self.checkRequiredField(combo.store.requiredArr, fieldName);
                    combo.store.filterBy(function (record) {
                        if (formType == 'filter') {
                            return record.get('sn') > 0 || record.get('title') == '全部顯示';
                        } else if (formType == 'add' && isRequiredField) {
                            return record.get('sn') > 0;
                        } else if (formType == 'add' && !isRequiredField) {
                            return record.get('sn') > 0 || record.get('title') == '　';
                        }
                    });
                    //篩選後選回值
                    (function () {
                        var originalValue = combo.getValue();
                        combo.selectByValue(originalValue, true);
                    }).defer(100);
                },
                specialkey: function (_this, e) {
                    if (!!specialkey) specialkey(_this, e);
                },
            }
        });
    }
    //* 切換顯示combo/comboS  *//
    this.switchCombo = function (checkbox, checked) {
        var comboS = checkbox.nextSibling().nextSibling();
        var combo = checkbox.nextSibling().nextSibling().nextSibling();
        if (checked) {//comboS
            //複選框篩選
            comboS.getStore().clearFilter();
            comboS.getStore().filterBy(r => r.get('sn') > 0);
            comboS.show();
            comboS.clearValue();
            combo.hide();
        } else {//combo
            //單選框篩選
            combo.getStore().clearFilter();
            combo.getStore().filterBy(r => r.get('sn') > 0 || r.get('title') == '全部顯示');
            combo.show();
            combo.clearValue();
            comboS.hide();
        }
    }
    //* 顯示隱藏(xtype為container)之下的item  *//
    this.setItemsHidden = function (item, formType) {//item=>xtype:container
        var checkbox = item.get("checkbox");
        var checkLabel = item.get("checkLabel");
        if (formType == "add") {
            checkbox.hide();
            checkLabel.hide();
        } else {
            checkbox.show();
            checkLabel.show();
        }
    }
    //* 清除篩選 *//
    this.clearSearch = function (form, formType) {
        for (var i = 0, itemsLength = form.items.length; i < itemsLength; i++) {
            var preFormItem = form.items.items[i];//各個項目
            var itemXtype = preFormItem.xtype;//container;numberfield;textfield;=>各個項目類型
            if (itemXtype == "container") {
                var isCheck = (preFormItem.get("checkbox")) ? preFormItem.get("checkbox").checked : "";//是否勾選
                var comboS = preFormItem.get("comboS");//複選框
                var combo = preFormItem.get("combo");//單選框
                //判斷項目值是使用單選框or複選框
                var formItem = (!!isCheck) ? comboS : combo;
                formItem.clearValue();
                formItem.lastQuery = "";
            } else {
                var formItem = preFormItem;
                formItem.setValue("");
            }
        }
        self.fieldStoreReset(form, formType);
    }
    //* 打開候選項清單  *//
    this.openCanditateWin = function (commCandidates, dataIndex, grid) {
        //commCandidates={"productSn": ["料品名稱", initParams.f_productSn],....}
        //dataIndex=>CM的dataIndex
        return new Ext.Window({
            title: `設定候選項-${commCandidates[dataIndex][0]}`, iconCls: 'setup', height: 450, width: 900, border: false,
            resizable: false, modal: true, closable: true, constrain: true, constrainHeader: true,
            closeAction: 'close', maximizable: false, maximized: false,//隱藏視窗,視窗可最大化,直接觸發最大化
            layout: 'fit',
            listeners: {
                render: function (obj) { Ext.ux.Loader.load([subHandler.subFolder + "materialOption.js?parentId=" + obj.id + "&mainId=" + mainId + "_p&dummy=" + new Date().getTime()]); },
                add: function (obj) {
                    var materialGrid = obj.items.items[0];
                    materialGrid.classifySn = commCandidates[dataIndex][1];//classifySn
                    materialGrid.storeName = commCandidates[dataIndex][2];//storeName
                    materialGrid.parentGrid = grid;//在哪個grid開啟
                    materialGrid.loadData();
                },
            }
        }).show();

    }
    //* 獲取結果(新增、篩選)同步重構共用  *//
    this.getResults = function (form) {
        var tooltip = "";//(1)資料篩選後提示字
        var inputFields = [];//(2)有輸入的欄位
        var paramsValueObj = {};//(3)輸出值(給後端)
        var isValueInStore = true;//(4)各欄位值是否存在於各自store
        var paramsCHObj = {};//(5)各欄位的combo title
        var results = {};
        for (var i = 0, itemsLength = form.items.length; i < itemsLength; i++) {
            //取出各個欄位內容(注意:依照xtype劃分)
            var preFormItem = form.items.items[i];
            var itemXtype = preFormItem.xtype;//container;numberfield;textfield=>各欄位類型
            if (itemXtype == "container") {
                var isCheck = (preFormItem.get("checkbox")) ? preFormItem.get("checkbox").checked : "";//是否勾選
                var comboS = preFormItem.get("comboS");//複選框
                var combo = preFormItem.get("combo");//單選框
                //判斷項目值是使用單選框or複選框
                formItem = (!!isCheck) ? comboS : combo;
            } else {//numberfield;textfield
                formItem = preFormItem;
            }
            //取得傳入表單(formItem)的各項目欄位資料
            fieldLabel = formItem.fieldLabel;//中
            fieldName = formItem.fieldName;//英
            //串提示字(不用傳給後端)
            if (formItem.itemId == "combo" || formItem.itemId == "comboS") {//container中的combo||comboS
                var store = formItem.store;
                var lastQuery = formItem.lastQuery;//輸入查詢的字
                fieldText = (formItem.lastSelectionText) ? formItem.lastSelectionText : lastQuery;//!提示字值
                //!取出值
                if (!!lastQuery) {//(檢查輸入值是否在store中 有:傳sn 無:傳中文字)
                    var queryIndex = store.findBy(r => r.get('title') == lastQuery);//判斷手輸值是在store中
                    var fieldTextIndex = store.findBy(r => r.get('title') == fieldText);//判斷選取值在store中index
                    if (fieldTextIndex >= 0) {
                        fieldValue = store.getAt(fieldTextIndex).get('sn');
                    } else if (queryIndex >= 0) {
                        fieldValue = store.getAt(queryIndex).get('sn');
                    } else {
                        fieldValue = lastQuery;
                        isValueInStore = false;//值不存在於store
                    }
                } else {
                    fieldValue = formItem.getValue();
                }
            } else {//numberfield;textfield
                fieldText = formItem.getValue();
                fieldValue = formItem.getValue();
            }
            if (!!fieldValue) {
                //Tooltip塞入
                tooltip += `${fieldLabel}：` + `${fieldText} <br>`;
                //紀錄有輸入的欄位
                inputFields.push(fieldName);
                //紀錄各欄位屬性:值
                paramsValueObj[fieldName] = fieldValue;
                //紀錄各欄位屬性:中文
                paramsCHObj[fieldName] = fieldText;
            }
        }
        results["tooltip"] = tooltip;
        results["inputFields"] = inputFields;
        results["paramsValueObj"] = paramsValueObj;
        results["isValueInStore"] = isValueInStore;
        results["paramsCHObj"] = paramsCHObj;
        return results;
    }
    //* 重整storeField *//
    self.fieldStoreReset = function (form, formType) {
        for (var i = 0, itemsLength = form.items.length; i < itemsLength; i++) {
            //取出各個欄位內容(注意:依照xtype劃分)
            var preFormItem = form.items.items[i];
            var itemXtype = preFormItem.xtype;//container;numberfield;textfield=>各欄位類型
            if (itemXtype == "container") {
                var isCheck = (preFormItem.get("checkbox")) ? preFormItem.get("checkbox").checked : "";//是否勾選
                var comboS = preFormItem.get("comboS");//複選框
                var combo = preFormItem.get("combo");//單選框
                //判斷項目值是使用單選框or複選框
                formItem = (!!isCheck) ? comboS : combo;
                formItemStore = formItem.store;
                formItemStore.clearFilter();//(先清除回到所有欄位再篩選)
                //篩選
                var isRequiredField = self.checkRequiredField(form.requiredArr, formItem.fieldName);
                formItemStore.filterBy(function (record) {
                    if (formType == 'filter') {
                        return record.get('sn') > 0 || record.get('title') == '全部顯示';
                    } else if (formType == 'add' && isRequiredField) {
                        return record.get('sn') > 0;
                    } else if (formType == 'add' && !isRequiredField) {
                        return record.get('sn') > 0 || record.get('title') == '　';
                    }
                });
            }
        }
    }
}
