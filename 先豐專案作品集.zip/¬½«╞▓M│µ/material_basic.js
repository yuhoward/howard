//基礎設定 
material_basic = function (subHandler, commObj) {
    var mainId = subHandler.mainId || subHandler.parentId;
    var self = this;
    //* 公域候選項 *//
    self.optionReader = new Ext.data.JsonReader({
        totalProperty: 'total', root: 'data',
        fields: [
            { name: 'classifySn', type: 'string' },
            { name: 'sn', type: 'int' },
            { name: 'title', type: 'string' },
            { name: 'remark', type: 'string' },
            { name: 'setName', type: 'string' },
            { name: 'setDate', type: 'string' },
            { name: 'uSn', type: 'string' }
        ]
    });
    //建立store name=>storeId名字,classifySn=>候選項sn(後端給),optionProxy=>檔案路徑,requiredArr=>必填欄位清單
    self.dataMaker = null;
    self.newStore = function (name, classifySn, optionProxy, requiredArr) {
        var store = Ext.StoreMgr.lookup(`${mainId}_${name}`);
        return store || new Ext.data.Store({
            requiredArr: requiredArr,//自訂變數
            storeId: `${mainId}_${name}`, remoteSort: true,
            proxy: optionProxy, reader: self.optionReader,
            baseParams: { classifySn: classifySn, isPaging: 0 },
            listeners: {
                load: function (_this) {
                    self.dataMaker = self.dataMaker || new Ext.data.Record.create(_this.reader.meta.fields);
                    var allShowRecord = new self.dataMaker({ sn: -99, title: '全部顯示' });
                    var nullRecord = new self.dataMaker({ sn: 0, title: '　' });
                    _this.insert(0, [allShowRecord, nullRecord]);
                },
            }
        })
    };
    //建立純資料store(無須action) name=>storeId名字,data=>從每隻檔案的init給(後端給),requiredArr=>必填欄位清單
    self.jsonMaker = null;
    self.newJsonStore = function (options) {
        var jsonStore = new Ext.data.JsonStore(Object.assign({
            autoDestroy: false, fields: [
                { name: 'sn', type: 'int' },
                { name: 'title', type: 'string' }
            ],
            storeId: null, data: null,
            requiredArr: null,//自訂參數
        }, options));
        self.jsonMaker = self.jsonMaker || new Ext.data.Record.create(jsonStore.reader.meta.fields)
        var allShowRecord = new self.jsonMaker({ sn: -99, title: '全部顯示' });
        var nullRecord = new self.jsonMaker({ sn: 0, title: '　' });
        jsonStore.insert(0, [allShowRecord, nullRecord]);
        return jsonStore;
    }
    //* 讀取所有store *//
    // allLoadedCb=>讀取完後的要做的事情callbackFn
    self.loadMultiStore = function (stores, allLoadedCb) {
        stores.forEach(store => {
            store.loaded = false;
            store.load({
                callback: (rs, options, success) => {
                    store.loaded = true;
                    if (!!allLoadedCb && stores.every(s => s.loaded)) allLoadedCb();
                }
            });
        });
    }
    //* grid(checkbox)的renderer *//
    self.checkRenderer = function (v, p, record) {
        p.css += ' x-grid3-check-col-td';
        return String.format('<div class="x-grid3-check-col{0}">&#160;</div>', v ? '-on' : '');
    };
    //* grid的ComboBox *//
    self.createCombo = function (fieldStore, isedit, fieldName, validator) {
        return new Ext.form.ComboBox({
            typeAhead: true, triggerAction: 'all', mode: 'local', lazyRender: true,
            allowBlank: true, blankText: '會篩選【候選項】值', msgTarget: 'side',
            listClass: 'x-combo-list-small', valueField: 'sn', displayField: 'title',//主要回傳後端值,顯示名稱
            tpl: '<tpl for="."><div class="x-combo-list-item" ext:qtip="{title} {remark}">{title} </div></tpl>',
            store: fieldStore,
            editable: isedit,
            validator,//驗證
            doQuery: function (q, forceAll) {
                q = Ext.isEmpty(q) ? '' : q;
                var qe = {
                    query: q,
                    forceAll: forceAll,
                    combo: this,
                    cancel: false
                };
                if (this.fireEvent('beforequery', qe) === false || qe.cancel) {
                    return false;
                }
                q = qe.query;
                forceAll = qe.forceAll;
                if (forceAll === true || (q.length >= this.minChars)) {
                    if (this.lastQuery !== q) {
                        this.lastQuery = q;
                        if (this.mode == 'local') {
                            this.selectedIndex = -1;
                            if (forceAll) {
                                this.store.clearFilter();
                            } else {
                                //改寫
                                var isRequiredField = commObj.checkRequiredField(this.store.requiredArr, fieldName);
                                if (!q) {
                                    this.store.filterBy(function (record) {
                                        if (isRequiredField) {
                                            return record.get('sn') > 0;
                                        } else {
                                            return record.get('sn') > 0 || record.get('title') == '　';
                                        }
                                    });
                                } else {
                                    this.store.filter(this.displayField, q);
                                }
                            }
                            this.onLoad();
                        } else {
                            this.store.baseParams[this.queryParam] = q;
                            this.store.load({
                                params: this.getParams(q)
                            });
                            this.expand();
                        }
                    } else {
                        this.selectedIndex = -1;
                        this.onLoad();
                    }
                }
            },
            listeners: {
                expand: function (_this) {
                    _this.store.clearFilter();//(先清除再篩選)
                    _this.store.filterBy(function (record) {
                        var isRequiredField = commObj.checkRequiredField(fieldStore.requiredArr, fieldName);
                        if (!isRequiredField) {
                            return record.get('sn') > 0 || record.get('title') == '　';//(包含空值)
                        } else {
                            return record.get('sn') > 0;
                        }
                    });
                }
            }
        });
    };
    //* 找出column的(候選項)store *//
    self.findCIStore = function (grid, column) {
        var CM = grid.getColumnModel();
        //column類型 string=>dataIndex,number=>cI
        var cI = (typeof (column) == 'string') ? CM.findColumnIndex(column) : column;
        var columnId = CM.getColumnId(cI);
        var column = CM.getColumnById(columnId);
        if (!column.editor || !column.editor.store) return;
        return column.editor.store;
    }

    //* 【文字、綠漆】"英文標題填寫"檢查 *//
    self.checkEnTitile = function (e, grid, record) {
        Ext.Ajax.request({
            method: 'POST', url: subHandler.subController + '&action=checkColorEng',
            params: { colorSn: record.get('colorSn') },
            success: function (result, request) {
                if (result.responseText == 'pass') {
                    record.set(e.field, !e.value);
                    grid.fireEvent('afteredit', {
                        'grid': e.grid,
                        'record': e.record,
                        'field': e.field,
                        'value': !e.value,
                        'originalValue': !e.value,
                        'row': e.row,
                        'column': e.column,
                    });
                } else {//engFail
                    Ext.Msg.show({
                        title: '錯誤', width: 250,
                        buttons: Ext.Msg.OK, icon: Ext.MessageBox.ERROR,
                        msg: `<font style='color:blue';>請先開啟【顏色】的候選項清單<br>設定「英文標題」</font>`,
                    });
                }
            },
            failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
        });
    };
    //* 是否勾選進階顯示的col設定 *//
    self.checkAdvCol = function (grid, advList) {
        var advBtnValue = grid.getTopToolbar().get('advBtn').checked;
        var CM = grid.getColumnModel();
        advList.forEach(field => {
            var fieldCI = CM.findColumnIndex(field);
            CM.setHidden(fieldCI, (advBtnValue) ? false : true);
        });
    }
    //* 【共用】標題右鍵清單 *//
    self.headerMenu = function (grid, cI, e) {
        e.preventDefault();
        // if (!grid.isAdmin) return; 判斷權限,功能暫時移除
        var dataIndex = grid.getColumnModel().getDataIndex(cI);//CM-dataIndex
        if (Object.keys(grid.commCandidates).indexOf(dataIndex) >= 0) {
            new Ext.menu.Menu({
                items: [
                    {
                        text: '候選項清單', iconCls: 'list', handler: function () { commObj.openCanditateWin(grid.commCandidates, dataIndex, grid); }
                    }
                ]
            }).showAt(e.getXY());
        }
    }
    //* 【共用】(新增、篩選視窗) *//
    self.creatWin = function (grid, tab, addForm, filterForm) {
        return new Ext.Window({
            layout: 'fit', closeAction: 'hide',
            title: '', height: 450, width: 280, border: false, autoHeight: true, shadow: false,
            resizable: false, modal: false, closable: true, constrain: true, constrainHeader: true,
            type: '',//自訂屬性
            items: tab,
            listeners: {
                show: function (win) {
                    if (win.type == 'add') Ext.getBody().mask();
                    grid.getTopToolbar().get('addBtn').setDisabled(win.type != 'add');
                    tab.getLayout().setActiveItem((win.type == 'add') ? 0 : 1);
                    win.setTitle((win.type == 'add') ? `新增資料-${grid["name"]}` : `篩選資料-${grid["name"]}`);
                    win.setIconClass((win.type == 'add') ? 'additem' : 'search');
                    if (win.type == 'add') {
                        commObj.fieldStoreReset(addForm, win.type);
                    } else {
                        commObj.fieldStoreReset(filterForm, win.type);
                    }
                },
                beforehide(win) {
                    Ext.getBody().unmask();
                    grid.getTopToolbar().get('addBtn').setDisabled(false);
                    //檢查新增是否輸入至一半
                    if (win.type == 'add') {
                        var results = commObj.getResults(addForm);//獲取新增表單結果
                        var paramsValue = JSON.stringify(results.paramsValueObj);
                        //檢查輸入的combo值是否在store中
                        if (paramsValue !== "{}") {
                            Ext.Msg.show({
                                title: '確認', width: 250,
                                buttons: Ext.Msg.YESNO, icon: Ext.MessageBox.QUESTION,
                                msg: `<font style='color:blue';>你確定要關閉?尚未新增成功<br>【輸入的內容將遺失】</font>`,
                                fn: function (btn) {
                                    if (btn == 'yes') {
                                        commObj.clearSearch(addForm, 'add');//清除表單內容
                                    } else {
                                        win.show();
                                    }
                                }
                            });
                        }
                    }
                }
            }
        });
    }
    //* 【共用】(tab) *//
    self.creatTab = function (addForm, filterForm) {
        return new Ext.Panel({
            layout: 'card', activeItem: 0, border: false, autoHeight: true,
            layoutConfig: { deferredRender: true, },
            items: [addForm, filterForm]
        });
    }
}