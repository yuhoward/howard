//coreList.js
// 移除了Grid編輯可直接新增選項功能
var subMain = function () {
    var layoutMain = function (initParams) {
        Ext.QuickTips.init();
        var mainId = subHandler.mainId || subHandler.parentId;
        var isAdmin = (subHandler.isAdmin == "true") ? true : false;//--工程
        var isEditor = (subHandler.isEditor == "true") ? true : false;//--資材
        //mainTab=>載入共用
        var mainTab = Ext.getCmp(mainId + '_material_mainPanel');
        var commObj = (mainTab) ? mainTab.commObj : new material_comm(subHandler);
        var basicObj = (mainTab) ? mainTab.basicObj : new material_basic(subHandler, commObj);
        //* 自訂變數 *//
        var coreWin = null;//(新增篩選窗)
        var advList = ['erp_Sync', 'spec', 'productName', 'modify_uName', 'modify_date'];//進階顯示清單
        var requiredArr = ["materialNo", "thickness", "thickness_unit", "thicknessType", "o_foilType_f", "o_foilType_s", "o_model", "core_widthUnitSn", "core_lengthUnitSn"];//所有必填欄位項目
        var addWinRequireArr = ["materialNo", "thickness", "thickness_unit", "thicknessType", "o_foilType_f", "o_foilType_s", "o_model"];//新增視窗必填欄位
        var commCandidates = {//公域候選項dataIndex:[中文,classifySn,storeName]
            "o_foilType_f": ["第一面銅箔類型", initParams.f_foilType, "foil_f"],
            "o_foilType_s": ["第二面銅箔類型", initParams.f_foilType, "foil_s"],
            "o_model": ["型號", initParams.f_model, "coreModel"],
            "formula": ["配方(玻纖布組成)", initParams.f_formula, "formula"],
        };
        var thicknessTypeData = [{ sn: 1, title: "(OA)" }, { sn: 2, title: "(CORE)" }];
        var gwData = [{ sn: 1, title: "G" }, { sn: 2, title: "W" }];
        //* 公域候選項Store *//
        var optionProxy = new Ext.data.HttpProxy({ url: `${subHandler.subController.replace('coreList', 'materialOption')}&action=loadOption&dummy=${new Date().getTime()} `, method: 'POST' });
        var ds_foilType_f = basicObj.newStore('foil_f', initParams.f_foilType, optionProxy, requiredArr);//銅箔類型(一)
        var ds_foilType_s = basicObj.newStore('foil_s', initParams.f_foilType, optionProxy, requiredArr);//銅箔類型(一)
        var ds_model = basicObj.newStore('coreModel', initParams.f_model, optionProxy, requiredArr);//型號
        var ds_formula = basicObj.newStore('formula', initParams.f_formula, optionProxy, requiredArr);//配方(玻纖布組成)
        var candidateStores = [ds_foilType_f, ds_foilType_s, ds_model, ds_formula];//候選項store陣列
        //* 獨立選項Store(後端&前端賦值) *//
        var ds_THKUnit = basicObj.newJsonStore({ storeId: mainId + '_coreTHKUnit', data: JSON.parse(initParams.THKUnitData), requiredArr: requiredArr });//板厚單位
        var ds_LWUnit = basicObj.newJsonStore({ storeId: mainId + '_coreLWUnit', data: JSON.parse(initParams.LWUnitData), requiredArr: requiredArr });//長寬單位
        var ds_thicknessType = basicObj.newJsonStore({ storeId: mainId + '_thicknessType', data: thicknessTypeData, requiredArr: requiredArr },);//板厚類型
        var ds_GW = basicObj.newJsonStore({ storeId: mainId + '_coreGW', data: gwData, requiredArr: requiredArr });//G/W
        //* function *//
        var changeGW = function (e) {
            var changeItem_dataIndex = (e.field == 'first_gw') ? 'second_gw' : 'first_gw';//需要切換的項目
            if (!!e.value) {
                var changeValue = (e.value == 1) ? 2 : 1;
                e.record.set(changeItem_dataIndex, changeValue);
                e.record.commit();
            } else {
                e.record.set(changeItem_dataIndex, 0);
                e.record.commit();
            }
        }
        var cmRenderer = function (v, m, r, rI, cI, s) {
            var dataIndex = coreGrid.getColumnModel().getDataIndex(cI);
            var CIStore = basicObj.findCIStore(coreGrid, cI);//CI所屬的Store           
            if (r.get('erp_Sync') == 1) {  //同步加顏色
                m.attr = 'style="background-image: url(/ext/resources/images/default/grid/grid3-hrow.gif);background-repeat: round;"';
            }
            if (!!CIStore) { var CIStoreRI = CIStore.find("sn", v) };//找到修改record在store的位置

            var returnVal = (CIStoreRI >= 0) ? CIStore.getAt(CIStoreRI).get('title') : v;
            if (dataIndex == 'erp_Sync') { returnVal = !!returnVal ? '已同步' : '未同步' };
            if (dataIndex == 'formula') { returnVal = (returnVal == "0" || returnVal == "　") ? '<span style="color:#C0C0C0">未設定</span>' : returnVal };
            if (!returnVal || returnVal == 0) returnVal = `<span style="color:${r.get('erp_Sync') == 1 ? 'red' : "#C0C0C0"}">未設定</span>`;

            return `<span ext:qtip='${returnVal}'>${returnVal}</span>`;
        }
        var updateList = function (e) {
            var record = e.record;
            var field = e.field;
            var value = e.value;
            var originalValue = e.originalValue;
            Ext.Ajax.request({
                method: 'POST', url: subHandler.subController + '&action=rowEdit',
                params: {
                    sn: record.get("sn"),
                    fieldName: field,
                    fieldValue: value,
                    fieldoldValue: originalValue
                },
                success: function (result, request) {
                    var resultArr = result.responseText.split(",");
                    if (resultArr[0] == "okEdit") {
                        record.commit();
                        Ext.ux.TopMsg.msg('通知', '<span style="color:green">更新成功</span>', 1, 100);
                        record.set("spec", resultArr[1]);//將「規格」欄位更新
                        record.set("productName", resultArr[2]);//將「品名」欄位更新
                        //更新編輯人員、時間
                        record.set("modify_uName", initParams.uName);
                        record.set("modify_date", Ext.util.Format.date(new Date(), 'Y-m-d H:i:s'));
                        if (field == 'first_gw' || field == 'second_gw') changeGW(e);//GW換位
                    } else if (resultArr[0] == "fail") {
                        Ext.MessageBox.alert('訊息', `材料編號「${resultArr[1]} 」已存在, 不可更改`);
                        record.set(e.field, e.originalValue);//設定回原本的
                        record.commit();
                    }
                },
                failure: function (response) { Ext.Msg.alert('Error', '伺服器連線發生問題(afterEdit),請通知管理人員'); },
            });
        }
        var createCoreForm = function (formType) {//filter->篩選,add->新增
            var specialkey_enterSearch = function (_this, e) {
                searchBtn = coreForm.getFooterToolbar().get("form_search");
                if (e.getKey() == e.ENTER && formType == 'filter') searchBtn.fireEvent("click");
            };
            var coreForm = new Ext.FormPanel({
                requiredArr: requiredArr,
                width: 270, boxMaxWidth: 270,
                labelWidth: 55, frame: false, bodyStyle: 'padding:10px', autoHeight: true,
                defaultType: 'textfield', border: false, buttonAlign: 'center',
                items: [
                    {
                        xtype: 'textfield', fieldLabel: '材料編號', emptyText: '材料編號', width: '185',
                        fieldName: 'materialNo',
                        listeners: {
                            render: function (field) { if (formType == 'filter') { commObj.setTooltip(field, 'material'); } },
                            specialkey: specialkey_enterSearch,
                        }
                    },
                    {
                        xtype: 'numberfield', fieldLabel: '板厚', emptyText: '板厚', width: '185', decimalPrecision: 4,
                        fieldName: 'thickness',
                        listeners: {
                            specialkey: specialkey_enterSearch,
                        }
                    },
                    {
                        xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '板厚(單位)', style: 'margin:4px 3px 0px 0px;' },
                            commObj.createCombo('板厚(單位)', 'thickness_unit', ds_THKUnit, formType, false, false, specialkey_enterSearch),
                        ]
                    },
                    {
                        xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '板厚類型', style: 'margin:4px 12px 0px 0px;' },
                            commObj.createCombo('板厚類型', 'thicknessType', ds_thicknessType, formType, false, false, specialkey_enterSearch),
                        ]
                    },
                    {
                        xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '第一面銅箔類型：', style: 'margin:4px 0px 0px 0px;' },
                            {
                                xtype: 'checkbox', itemId: 'checkbox', checked: false, listeners: {
                                    check: function (_this, checked) {
                                        commObj.switchCombo(_this, checked);//切換顯示combo/comboS
                                    }
                                }
                            },
                            { xtype: 'label', itemId: 'checkLabel', text: '複選', style: 'font-size:11px;margin:3px 5px 0px 0px;' },
                            commObj.createComboS('第一面銅箔類型', 'o_foilType_f', ds_foilType_f, formType),
                            commObj.createCombo('第一面銅箔類型', 'o_foilType_f', ds_foilType_f, formType, true, true, specialkey_enterSearch, function (value) {
                                return (!value || ds_foilType_f.getRange().some(r => r.get('title') == value)) || '選項不存在';
                            }),
                        ],
                        listeners: {
                            afterrender: function (item) {//item=>這個container
                                commObj.setItemsHidden(item, formType);
                            }
                        }
                    },
                    {
                        xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '第二面銅箔類型：', style: 'margin:4px 0px 0px 0px;' },
                            {
                                xtype: 'checkbox', itemId: 'checkbox', checked: false, listeners: {
                                    check: function (_this, checked) {
                                        commObj.switchCombo(_this, checked);//切換顯示combo/comboS
                                    }
                                }
                            },
                            { xtype: 'label', itemId: 'checkLabel', text: '複選', style: 'font-size:11px;margin:3px 5px 0px 0px;' },
                            commObj.createComboS('第二面銅箔類型', 'o_foilType_s', ds_foilType_s, formType),
                            commObj.createCombo('第二面銅箔類型', 'o_foilType_s', ds_foilType_s, formType, true, true, specialkey_enterSearch, function (value) {
                                return (!value || ds_foilType_s.getRange().some(r => r.get('title') == value)) || '選項不存在';
                            }),
                        ],
                        listeners: {
                            afterrender: function (item) {//item=>這個container
                                commObj.setItemsHidden(item, formType);
                            }
                        }
                    },
                    {
                        xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '基板型號：', style: 'margin:4px 36px 0px 0px;' },
                            {
                                xtype: 'checkbox', itemId: 'checkbox', checked: false, listeners: {
                                    check: function (_this, checked) {
                                        commObj.switchCombo(_this, checked);//切換顯示combo/comboS
                                    }
                                }
                            },
                            { xtype: 'label', itemId: 'checkLabel', text: '複選', style: 'font-size:11px;margin:3px 5px 0px 0px;' },
                            commObj.createComboS('基板型號', 'o_model', ds_model, formType),
                            commObj.createCombo('基板型號', 'o_model', ds_model, formType, true, true, specialkey_enterSearch, function (value) {
                                return (!value || ds_model.getRange().some(r => r.get('title') == value)) || '選項不存在';
                            }),
                        ],
                        listeners: {
                            afterrender: function (item) {//item=>這個container
                                commObj.setItemsHidden(item, formType);
                            }
                        }
                    },
                    {
                        hidden: formType == 'add', xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '玻纖布組成：', style: 'margin:4px 24px 0px 0px' },
                            {
                                xtype: 'checkbox', itemId: 'checkbox', checked: false, listeners: {
                                    check: function (_this, checked) {
                                        commObj.switchCombo(_this, checked);//切換顯示combo/comboS
                                    }
                                }
                            },
                            { xtype: 'label', itemId: 'checkLabel', text: '複選', style: 'font-size:11px;margin:3px 5px 0px 0px;' },
                            commObj.createComboS('玻纖布組成', 'formula', ds_formula, formType),
                            commObj.createCombo('玻纖布組成', 'formula', ds_formula, formType, true, true, specialkey_enterSearch, function (value) {
                                return (!value || ds_formula.getRange().some(r => r.get('title') == value)) || '選項不存在';
                            }),
                        ],
                        listeners: {
                            afterrender: function (item) {//item=>這個container
                                commObj.setItemsHidden(item, formType);
                            }
                        }
                    },
                    {
                        hidden: formType == 'add', xtype: 'textfield', fieldLabel: '寬度', emptyText: '寬度', width: '185',
                        fieldName: 'width',
                        listeners: {
                            render: function (field) { if (formType == 'filter') { commObj.setTooltip(field, 'range'); } },
                            specialkey: specialkey_enterSearch,
                        }
                    },
                    {
                        hidden: formType == 'add', xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '寬度(單位)', style: 'margin:4px 3px 0px 0px;' },
                            commObj.createCombo('寬度(單位)', 'core_widthUnitSn', ds_LWUnit, formType, false, false, specialkey_enterSearch),
                        ]
                    },
                    {
                        hidden: formType == 'add', xtype: 'textfield', fieldLabel: '長度', emptyText: '長度', width: '185',
                        fieldName: 'length',
                        listeners: {
                            render: function (field) { if (formType == 'filter') { commObj.setTooltip(field, 'range'); } },
                            specialkey: specialkey_enterSearch,
                        }
                    },
                    {
                        hidden: formType == 'add', xtype: 'container', layout: 'column', style: 'margin:0px 0px 6px 0px ',
                        items: [
                            { xtype: 'label', text: '長度(單位)', style: 'margin:4px 3px 0px 0px;' },
                            commObj.createCombo('長度(單位)', 'core_lengthUnitSn', ds_LWUnit, formType, false, false, specialkey_enterSearch),
                        ]
                    },
                    {
                        hidden: formType == 'add', xtype: 'textfield', fieldLabel: '備註', emptyText: '備註', width: '185',
                        fieldName: 'remark',
                        listeners: {
                            specialkey: specialkey_enterSearch,
                        }
                    },
                ],
                buttons: [
                    {
                        hidden: formType != 'add', xype: 'button', itemId: '', text: '新增', iconCls: 'ok', handler: function (btn) {
                            var isAddPass = true;//是否能新增
                            var results = commObj.getResults(coreForm);//獲取表單結果
                            var inputFields = results["inputFields"];//取出有輸入的欄位
                            //檢查必填欄位
                            for (var i = 0, length = addWinRequireArr.length; i < length; i++) {
                                if (inputFields.indexOf(addWinRequireArr[i]) < 0) {
                                    isAddPass = false;
                                    Ext.Msg.alert('訊息', '此視窗內容尚未填寫完整');
                                    break;
                                }
                            }
                            //檢查輸入的combo值是否在store中
                            if (!results["isValueInStore"]) {
                                isAddPass = false;
                                Ext.ux.TopMsg.msg('提醒', '<span style="color:red">有值不存在，請修正!</span>', 5, 180);
                                return;
                            }
                            if (isAddPass) {
                                var paramsValueObj = results.paramsValueObj;
                                Ext.Msg.show({
                                    title: '確認', iconCls: 'info', width: 250,
                                    buttons: Ext.Msg.YESNO, icon: Ext.MessageBox.QUESTION,//Ext.Msg.YESNO//Ext.Msg.OK,
                                    msg: `<font style='color:blue';>確定要新增此材料編號?「${paramsValueObj["materialNo"]}」</font>`,
                                    fn: function (btn) {
                                        if (btn == 'yes') {
                                            Ext.Ajax.request({
                                                method: 'POST', url: subHandler.subController + '&action=addData',
                                                params: { itemValue: JSON.stringify(results.paramsValueObj) },
                                                success: function (result, request) {
                                                    var resultArr = result.responseText.split(',');
                                                    var resultType = resultArr[0];
                                                    if (resultType == 'okAdd') {
                                                        var newRecord = new coreStore.recordMaker({
                                                            sn: resultArr[1],
                                                            erp_Sync: 0,//erp同步
                                                            materialNo: paramsValueObj["materialNo"],//!材料編號(必填)
                                                            spec: resultArr[2],//規格
                                                            thickness: paramsValueObj["thickness"],//!板厚(必填)
                                                            thickness_unit: paramsValueObj["thickness_unit"],//!板厚單位(必填)
                                                            thicknessType: paramsValueObj["thicknessType"],//!板厚類型(必填)
                                                            o_foilType_f: paramsValueObj["o_foilType_f"], o_foilType_s: paramsValueObj["o_foilType_s"],//!第一、二面銅箔類型(必填)
                                                            o_model: paramsValueObj["o_model"],//!基板型號(必填)
                                                            core_widthUnitSn: 18,//寬單位(預設inch)
                                                            first_gw: 0,//第一個經緯
                                                            core_lengthUnitSn: 18,//長單位(預設inch)
                                                            second_gw: 0,//第二個經緯
                                                            setName: initParams.uName,
                                                            setDate: Ext.util.Format.date(new Date(), 'Y-m-d H:i:s'),
                                                            modify_uName: initParams.uName,//最後編輯人員
                                                            modify_date: Ext.util.Format.date(new Date(), 'Y-m-d H:i:s'),//最後編輯時間
                                                        });
                                                        coreGrid.stopEditing();
                                                        coreStore.insert(0, newRecord);
                                                        Ext.ux.TopMsg.msg('提醒', '<span style="color:green">新增成功!</span>', 5, 100);
                                                        commObj.clearSearch(coreForm, formType);//清除篩選框項目/內容
                                                        coreWin.hide();
                                                    } else if (resultType == 'materialNoFail') {
                                                        Ext.MessageBox.alert('訊息', `<font color="red">新增失敗!</font><br>材料編號「${resultArr[1]} 」已存在`);
                                                    }
                                                },
                                                failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                                            });
                                        }
                                    }
                                });
                            }
                        }
                    },
                    {
                        hidden: formType == 'add', xype: 'button', itemId: 'form_search', text: '篩選', iconCls: 'search',
                        listeners: {
                            click: function () {
                                var results = commObj.getResults(coreForm);//獲取表單結果
                                var paramsValue = JSON.stringify(results.paramsValueObj);
                                //檢查輸入的combo值是否在store中
                                if (paramsValue == "{}") {
                                    Ext.Msg.alert('訊息', '篩選條件不得為空!');
                                    return;
                                }
                                var filterTooltip = results.tooltip;
                                coreGrid.getTopToolbar().get("search").setTooltip(filterTooltip);
                                coreGrid.getTopToolbar().get("search").setText(`<span style="color:red;">資料篩選</span>`);
                                coreStore.baseParams = { searchItem: paramsValue };
                                coreStore.load();
                            }
                        }
                    },
                    {
                        xype: 'button', itemId: '', text: '清除', iconCls: 'clearInput',
                        listeners: {
                            click: function (btn, e) {
                                commObj.clearSearch(coreForm, formType);//清除表單內容
                                if (formType == 'filter') {
                                    //設定coreGrid(最外層)的"資料篩選"按鈕
                                    coreGrid.getTopToolbar().get("search").setTooltip("");
                                    coreGrid.getTopToolbar().get("search").setText(`<span>資料篩選</span>`);
                                    //(傳空)撈取所有資料(清除資料)
                                    coreStore.baseParams = {};
                                    coreStore.load();
                                }
                            }
                        }
                    },
                ]
            })
            return coreForm;
        }

        //* addCoreForm(把Form記錄下來) *//
        var addCoreForm = createCoreForm('add');
        //* filterCoreForm(把Form記錄下來) *//
        var filterCoreForm = createCoreForm('filter');

        //* 基板(新增/篩選)Tab *//
        var coreTab = basicObj.creatTab(addCoreForm, filterCoreForm);

        //* 基板Store&Grid *//
        var coreStore = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({ url: `${subHandler.subController}&action=loadList&dummy=${new Date().getTime()} `, method: 'POST' }),
            reader: new Ext.data.JsonReader({
                totalProperty: 'total', root: 'data',
                fields: [
                    { name: 'sn', type: 'string' },
                    { name: 'erp_Sync', type: 'int' },//!erp同步
                    { name: 'materialNo', type: 'string', },//材料編號
                    { name: 'spec', type: 'string' },//規格
                    { name: 'thickness', type: 'string' },//板厚
                    { name: 'thickness_unit', type: 'int' },//板厚單位
                    { name: 'thicknessType', type: 'string' },//板厚類型
                    { name: 'o_foilType_f', type: 'string' },//第一面銅箔類型
                    { name: 'o_foilType_s', type: 'string' },//第二面銅箔類型
                    { name: 'o_model', type: 'string' },//基板型號
                    { name: 'originNo', type: 'string' },//!產地代號
                    { name: 'dk', type: 'string' },//!Dk
                    { name: 'width', type: 'string' },//寬
                    { name: 'core_widthUnitSn', type: 'string' },//寬單位
                    { name: 'first_gw', type: 'string' },//!第一個經緯
                    { name: 'long', type: 'string' },//長
                    { name: 'core_lengthUnitSn', type: 'string' },//長單位
                    { name: 'second_gw', type: 'string' },//!第二個經緯
                    { name: 'productName', type: 'string' },//品名
                    { name: 'noHalogen', type: 'string' },//!無鹵
                    { name: 'coreItem', type: 'string' },//!品項
                    { name: 'firstFacefirm_CopperFoilType', type: 'string' },//!第一面廠商_銅箔類型
                    { name: 'supplierUpstream_CopperFoilModel_one', type: 'string' },//!供應商上游_銅箔型號
                    { name: 'secondFacefirm_CopperFoilType', type: 'string' },//!第二面廠商_銅箔類型
                    { name: 'supplier_Upstream_CopperFoilModel_two', type: 'string' },//!供應商上游_銅箔型號(二)
                    { name: 'origin', type: 'string' },//!產地
                    { name: 'formula', type: 'string' },//!(配方)改名=>玻纖布組成
                    { name: 'thickness_control', type: 'string' },//!厚度管控
                    { name: 'supplier_CopperFoilModel_one', type: 'string' },//!供應商_銅箔型號
                    { name: 'supplier_CopperFoilModel_two', type: 'string' },//!供應商_銅箔型號(二)
                    { name: 'copperFoilSupplier_one', type: 'string' },//!銅箔供應商
                    { name: 'copperFoilSupplier_two', type: 'string' },//!銅箔供應商(二)
                    { name: 'glassCloth_rc', type: 'string' },//!玻布RC值
                    { name: 'glassCloth_supplier', type: 'string' },//!玻布供應商
                    { name: 'remark', type: 'string' },//備註
                    { name: 'setName', type: 'string' },//建立人員
                    { name: 'setDate', type: 'string' },//建立時間
                    { name: 'modify_uName', type: 'string' },//編輯人員
                    { name: 'modify_date', type: 'string' },//編輯日期
                ]
            }),
        });
        var coreGrid = new Ext.grid.EditorGridPanel({
            coreWin: coreWin,//基板視窗(main.js判斷用)
            commCandidates: commCandidates,
            name: '基板',
            from: 'material',
            isAdmin: isAdmin,
            id: mainId + "_coreGrid", border: false, autoExpandColumn: 0,
            loadMask: true, stripeRows: false, columnLines: true, trackMouseOver: true, //讀取圖案,條紋列顏色,分隔線,滑鼠滑過
            view: new Ext.ux.grid.LockingGridView(),//orGroupingView
            selModel: new Ext.grid.RowSelectionModel({ singleSelect: true, moveEditorOnEnter: false }), //列單選
            store: coreStore,
            cm: new Ext.ux.grid.LockingColumnModel({
                defaults: { align: 'center', menuDisabled: false, renderer: cmRenderer },
                columns: [
                    { hidden: true, header: 'sn', dataIndex: 'sn', width: 55, },
                    { header: 'ERP同步', dataIndex: 'erp_Sync', },
                    { header: '材料編號', dataIndex: 'materialNo', align: 'left', width: 150, editor: new Ext.form.TextField(), },
                    { header: '<span style="color:blue">規格</span>', dataIndex: 'spec', align: 'left', width: 455, css: 'background-image: url(/ext/resources/images/default/grid/grid3-hrow.gif);background-repeat: round;', },
                    { header: '板厚', dataIndex: 'thickness', width: 60, editor: new Ext.form.NumberField({ decimalPrecision: 4 }), },
                    { header: '板厚<br>單位', dataIndex: 'thickness_unit', width: 55, editor: basicObj.createCombo(ds_THKUnit, false, 'thickness_unit') },
                    { header: '板厚<br>類型', dataIndex: 'thicknessType', width: 60, editor: basicObj.createCombo(ds_thicknessType, false, 'thicknessType') },
                    {
                        header: '<u>第一面<br>銅箔類型<span style="color:red">*</span></u>', dataIndex: 'o_foilType_f', width: 80,
                        editor: basicObj.createCombo(ds_foilType_f, true, 'o_foilType_f', function (value) {
                            return ds_foilType_f.getRange().some(r => r.get('title') == value) || '選項不存在';
                        })
                    },
                    {
                        header: '<u>第二面<br>銅箔類型<span style="color:red">*</span></u>', dataIndex: 'o_foilType_s', width: 80,
                        editor: basicObj.createCombo(ds_foilType_s, true, 'o_foilType_s', function (value) {
                            return ds_foilType_s.getRange().some(r => r.get('title') == value) || '選項不存在';
                        })
                    },
                    {
                        header: '<u>基板型號<span style="color:red">*</span></u>', dataIndex: 'o_model',
                        editor: basicObj.createCombo(ds_model, true, 'o_model', function (value) {
                            return ds_model.getRange().some(r => r.get('title') == value) || '選項不存在';
                        })
                    },
                    { header: '產地代號', dataIndex: 'originNo', width: 75, editor: new Ext.form.TextField(), },
                    { header: 'Dk', dataIndex: 'dk', width: 80, editor: new Ext.form.TextField(), },
                    { header: '寬', dataIndex: 'width', width: 55, editor: new Ext.form.NumberField({ decimalPrecision: 2 }), },
                    { header: '寬單位', dataIndex: 'core_widthUnitSn', width: 65, editor: basicObj.createCombo(ds_LWUnit, false, 'core_widthUnitSn', null) },
                    { header: 'G/W', dataIndex: 'first_gw', width: 55, editor: basicObj.createCombo(ds_GW, false, 'first_gw') },
                    { header: '長', dataIndex: 'long', width: 55, editor: new Ext.form.NumberField({ decimalPrecision: 2 }), },
                    { header: '長單位', dataIndex: 'core_lengthUnitSn', width: 65, editor: basicObj.createCombo(ds_LWUnit, false, 'core_lengthUnitSn', null) },
                    { header: 'G/W', dataIndex: 'second_gw', width: 55, editor: basicObj.createCombo(ds_GW, false, 'second_gw') },
                    { header: '<span style="color:blue">品名</span>', dataIndex: 'productName', align: 'left', width: 480, },
                    { header: '無鹵', dataIndex: 'noHalogen', editor: new Ext.form.TextField(), },
                    { header: '品項', dataIndex: 'coreItem', editor: new Ext.form.TextField(), },
                    { header: '第一面廠商<br>銅箔類型', dataIndex: 'firstFacefirm_CopperFoilType', editor: new Ext.form.TextField(), },
                    { header: '供應商上游<br>銅箔型號', dataIndex: 'supplierUpstream_CopperFoilModel_one', editor: new Ext.form.TextField(), },
                    { header: '第二面廠商<br>銅箔類型', dataIndex: 'secondFacefirm_CopperFoilType', editor: new Ext.form.TextField(), },
                    { header: '供應商上游<br>銅箔型號(二)', dataIndex: 'supplier_Upstream_CopperFoilModel_two', editor: new Ext.form.TextField(), },
                    { header: '產地', dataIndex: 'origin', editor: new Ext.form.TextField(), },
                    {
                        header: '<u>玻纖布組成<span style="color:red">*</span></u>', dataIndex: 'formula',
                        editor: basicObj.createCombo(ds_formula, true, 'formula', function (value) {
                            return (!value || ds_formula.getRange().some(r => r.get('title') == value)) || '選項不存在';
                        })
                    },
                    { header: '厚度管控', dataIndex: 'thickness_control', editor: new Ext.form.TextField(), },
                    { header: '供應商<br>銅箔型號', dataIndex: 'supplier_CopperFoilModel_one', editor: new Ext.form.TextField(), },
                    { header: '供應商<br>銅箔型號(二)', dataIndex: 'supplier_CopperFoilModel_two', editor: new Ext.form.TextField(), },
                    { header: '銅箔<br>供應商', dataIndex: 'copperFoilSupplier_one', editor: new Ext.form.TextField(), },
                    { header: '銅箔<br>供應商(二)', dataIndex: 'copperFoilSupplier_two', editor: new Ext.form.TextField(), },
                    { header: '玻布<br>RC值', dataIndex: 'glassCloth_rc', editor: new Ext.form.TextField(), },
                    { header: '玻布<br>供應商', dataIndex: 'glassCloth_supplier', editor: new Ext.form.TextField(), },
                    { header: '備註', dataIndex: 'remark', align: 'left', width: 185, editor: new Ext.form.TextField(), },
                    { header: '<span style="color:blue">最後編輯人員</span>', dataIndex: 'modify_uName', },
                    { header: '<span style="color:blue">最後編輯日期</span>', dataIndex: 'modify_date', width: 130 },
                ],
            }),
            tbar: [
                {//資料篩選
                    xtype: 'button', text: '資料篩選', itemId: 'search', iconCls: "search",
                    handler: function (btn) {
                        coreWin.type = 'filter';
                        coreWin.show();
                    }
                }, '-',
                {//進階顯示
                    xtype: 'checkbox', boxLabel: '進階顯示', itemId: 'advBtn',
                    listeners: {
                        check: function (_this, checked) {
                            var coreCM = coreGrid.getColumnModel();
                            advList.forEach(field => {
                                var fieldCI = coreCM.findColumnIndex(field);
                                coreCM.setHidden(fieldCI, (checked) ? false : true);
                            });
                        }
                    }
                }, '-',
                {//固定材料編號及規格
                    xtype: 'checkbox', boxLabel: '固定材料編號及規格', itemId: '',
                    listeners: {
                        check: function (_this, checked) {
                            var coreCM = coreGrid.getColumnModel();
                            if (checked) {
                                var materialNoIndex = coreCM.findColumnIndex('materialNo');
                                var specIndex = coreCM.findColumnIndex('spec');
                                coreCM.setLocked(materialNoIndex, true, false);
                                coreCM.moveColumn(materialNoIndex, 0);
                                coreCM.setLocked(specIndex, true, false);
                                coreCM.moveColumn(specIndex, 1);
                            } else {
                                var materialNoIndex = coreCM.findColumnIndex('materialNo');
                                var erp_SyncIndex = coreCM.findColumnIndex('erp_Sync');
                                var specIndex = coreCM.findColumnIndex('spec');
                                coreCM.moveColumn(specIndex, erp_SyncIndex);
                                erp_SyncIndex = coreCM.findColumnIndex('erp_Sync');//在抓一次
                                coreCM.moveColumn(materialNoIndex, erp_SyncIndex)
                            }
                        }
                    }
                }, '->',
                { xtype: 'tbtext', text: '<span style="color:red;border:1.5px yellow solid; padding:2px">注意:編輯後即儲存</span>' }, '-',
                {//啟用編輯
                    xtype: 'button', text: '啟用編輯', iconCls: 'edit', itemId: 'editBtn', enableToggle: true, tooltip: '<b>啟用後<font color=red>雙擊</font>可進行編輯</b>',
                    listeners: {
                        click: function (btn, e) {
                            Ext.MessageBox.confirm('提示', "您確定要『" + btn.text + "』?", function (b) {
                                if (b == 'yes') {
                                    btn.pressed = (btn.pressed) ? true : false;
                                    btn.setIconClass((btn.pressed) ? 'cancel' : 'edit');
                                    btn.setText((btn.pressed) ? '關閉編輯' : '啟用編輯');
                                    btn.setTooltip((btn.pressed) ? '關閉編輯' : '<b>啟用後<font color=red>雙擊</font>可進行編輯</b>');

                                } else {
                                    (btn.pressed) ? btn.toggle(false) : btn.toggle(true);
                                    btn.setIconClass((btn.pressed) ? 'cancel' : 'edit');
                                    btn.setText((btn.pressed) ? '關閉編輯' : '啟用編輯');
                                }
                            });
                        }
                    }
                }, '-',
                {//新增
                    text: '新增', iconCls: 'add', itemId: 'addBtn',
                    listeners: {
                        click: function (b) {
                            coreWin.type = 'add';
                            coreWin.show();
                        }
                    }
                },
            ],
            bbar: new Ext.PagingToolbar({ store: coreStore, displayInfo: true, pageSize: initParams.pageSize, displayMsg: "顯示數量{0}-{1},共{2}筆" }),
            listeners: {
                afterrender: function (grid) {
                    if (grid.from == 'material') basicObj.checkAdvCol(grid, advList);//進階顯示勾選處理
                    coreStore.load({
                        callback: () => coreStore.recordMaker = coreStore.recordMaker || new Ext.data.Record.create(coreStore.reader.meta.fields)
                    });
                },
                beforeedit(e) {
                    var r = e.record;
                    var editBtn = coreGrid.getTopToolbar().get('editBtn');
                    return (editBtn.pressed && r.get('erp_Sync') != 1);
                },
                afteredit: function (e) {
                    if ((e.field == 'materialNo' || e.field == 'thickness') && e.value == "") {
                        Ext.MessageBox.alert("錯誤", '不可輸入空值');
                        e.record.set(e.field, e.originalValue);//設定回初始值
                        e.record.commit();
                        return false;
                    }
                    updateList(e);
                },
                headercontextmenu: basicObj.headerMenu,
                rowcontextmenu: function (grid, rI, e) {
                    e.preventDefault();
                    var coreSM = grid.getSelectionModel();
                    coreSM.selectRow(rI);
                    var record = coreSM.getSelected(); //取得record
                    var editBtn = coreGrid.getTopToolbar().get('editBtn');
                    if (editBtn.pressed) {
                        if (record) {
                            new Ext.menu.Menu({
                                autoDestroy: true,
                                items: [
                                    {
                                        itemId: 'delBtn', text: '刪除', iconCls: 'del',
                                        handler: function (b) {
                                            Ext.Msg.show({
                                                title: '確認', iconCls: 'info', width: 250,
                                                buttons: Ext.Msg.YESNO, icon: Ext.MessageBox.QUESTION,
                                                msg: `<font style="color:blue";>材料編號：【${record.get("materialNo")}】<br>` +
                                                    `你確定要刪除?<br>此動作無法復原。</font>`,
                                                fn: function (btn) {
                                                    if (btn == 'yes') {
                                                        Ext.Ajax.request({
                                                            method: 'POST', url: subHandler.subController + '&action=rowDel',
                                                            params: { sn: record.get("sn") },
                                                            success: function (result, request) {
                                                                if (result.responseText == 'okDel') {
                                                                    coreGrid.getStore().remove(record);
                                                                    Ext.ux.TopMsg.msg('通知', '<span style="color:red">刪除成功</span>', 1, 100);
                                                                } else if (result.responseText == 'isLock') {//可能在工程中「剛」被使用
                                                                    Ext.ux.TopMsg.msg('通知', '<span style="color:red">工程規範系統使用中，無法刪除</span>', 3, 180);
                                                                } else {
                                                                    Ext.Msg.alert('Error', '刪除失敗:' + result.responseText);
                                                                }
                                                            },
                                                            failure: function (response) { Ext.Msg.alert('Error', '無法連線伺服器'); },
                                                        });
                                                    }
                                                }
                                            });
                                        }
                                    }
                                ],
                                listeners: {
                                    beforeshow: function (_this) {
                                        if (record.get("erp_Sync") == 1) _this.getComponent("delBtn").disable();
                                    },
                                }
                            }).showAt(e.getXY());
                        }
                    }
                }
            }
        });

        //* 基板(新增/篩選)視窗 *//
        coreWin = coreWin || basicObj.creatWin(coreGrid, coreTab, addCoreForm, filterCoreForm);
        coreGrid.coreWin = coreWin;

        //load
        basicObj.loadMultiStore(candidateStores, () => { subHandler.doLayout(coreGrid) });
    }
    var subHandler = new getHandler();
    Ext.ux.Loader.load(["ux_comboS", "ux_qtipMember", "ux_exporter",
        subHandler.subFolder + '/material_comm.js',
        subHandler.subFolder + '/material_basic.js',], function () {
            subHandler.initParam(layoutMain);//init js base params from ajax
        }, subHandler);
}();